package com.example.videoplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private var vids = listOf<Vid>()
    private var songs = listOf<Song>()
    private var pics = listOf<Pic>()
    private var tab = 0
    private var audioSub = 0
    private var photoSub = 0
    private var videoFolder: String? = null
    private var audioGroup: Pair<Int, String>? = null
    private var photoAlbum: String? = null
    private var loaded = false

    private lateinit var topHolder: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: ImageView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.bg()
        topHolder = FrameLayout(this)
        content = FrameLayout(this)
        root.addView(topHolder, LinearLayout.LayoutParams(-1, -2))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildMini(), LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        if (granted()) reload() else ask()
        render()
    }

    override fun onStart() {
        super.onStart()
        Music.listen("main") { updateMini() }
        updateMini()
    }

    override fun onStop() {
        super.onStop()
        Music.unlisten("main")
    }

    // ---------- permissions ----------
    private fun mediaPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_IMAGES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun granted() = mediaPerms().any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun ask() {
        val l = mediaPerms().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(l.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (granted()) reload() else render()
    }

    private fun reload() {
        Thread {
            val v = Repo.videos(this)
            val s = Repo.songs(this)
            val p = Repo.pics(this)
            runOnUiThread { vids = v; songs = s; pics = p; loaded = true; render() }
        }.start()
    }

    override fun onBackPressed() {
        when {
            tab == 1 && videoFolder != null -> { videoFolder = null; render() }
            tab == 2 && audioGroup != null -> { audioGroup = null; render() }
            tab == 3 && photoAlbum != null -> { photoAlbum = null; render() }
            else -> super.onBackPressed()
        }
    }

    // ---------- UI helpers ----------
    private fun strip(labels: List<String>, sel: Int, onSel: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        labels.forEachIndexed { i, t ->
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val tv = TextView(this)
            tv.text = t.uppercase()
            tv.textSize = 15f
            tv.setTypeface(null, Typeface.BOLD)
            tv.setTextColor(if (i == sel) Ui.ACCENT else Color.WHITE)
            tv.setPadding(dp(16), dp(12), dp(16), dp(8))
            val line = View(this)
            line.setBackgroundColor(if (i == sel) Ui.ACCENT else Color.TRANSPARENT)
            col.addView(tv)
            col.addView(line, LinearLayout.LayoutParams(-1, dp(3)))
            col.setOnClickListener { onSel(i) }
            row.addView(col)
        }
        hs.addView(row)
        return hs
    }

    private fun msg(text: String, onClick: (() -> Unit)? = null): View {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(32), dp(32), dp(32), dp(32))
        if (onClick != null) tv.setOnClickListener { onClick() }
        return tv
    }

    private fun withHeader(text: String, body: View): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.parseColor("#B3FFFFFF"))
        tv.textSize = 13f
        tv.setPadding(dp(16), dp(8), dp(16), dp(4))
        l.addView(tv)
        l.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        return l
    }

    private fun styleList(lv: ListView) {
        lv.setBackgroundColor(Color.TRANSPARENT)
        lv.cacheColorHint = Color.TRANSPARENT
        lv.selector = ColorDrawable(Color.parseColor("#22FFFFFF"))
        lv.divider = ColorDrawable(Color.parseColor("#22FFFFFF"))
        lv.dividerHeight = 1
    }

    private fun rowList(rows: List<Row>, onClick: (Int) -> Unit): ListView {
        val lv = ListView(this)
        styleList(lv)
        lv.adapter = RowAdapter(this, rows)
        lv.setOnItemClickListener { _, _, p, _ -> onClick(p) }
        return lv
    }

    // ---------- render ----------
    private fun render() {
        topHolder.removeAllViews()
        topHolder.addView(strip(listOf("Video", "Folder", "Audio", "Photo"), tab) { tab = it; render() })
        content.removeAllViews()
        if (!loaded) {
            content.addView(
                if (granted()) msg("Loading...")
                else msg("Permission is needed to show your videos, music and photos. Tap here to allow.") { ask() },
                FrameLayout.LayoutParams(-1, -1))
        } else {
            val v = when (tab) {
                0 -> withHeader("${vids.size} videos", videoList(vids))
                1 -> videoFolders()
                2 -> audioPage()
                else -> photoPage()
            }
            content.addView(v, FrameLayout.LayoutParams(-1, -1))
        }
        updateMini()
    }

    // ---------- video ----------
    private fun videoList(list: List<Vid>): View {
        if (list.isEmpty()) return msg("No videos found on this phone.")
        return rowList(list.map { Row(it.name, fmt(it.durationMs), it.uri) }) { pos ->
            startActivity(
                Intent(this, PlayerActivity::class.java)
                    .putStringArrayListExtra("u", ArrayList(list.map { it.uri.toString() }))
                    .putExtra("i", pos)
            )
        }
    }

    private fun videoFolders(): View {
        val vf = videoFolder
        if (vf != null) {
            val l = vids.filter { it.folder == vf }
            return withHeader("${folderName(vf)} - ${l.size} videos", videoList(l))
        }
        val groups = vids.groupBy { it.folder }.entries.sortedBy { folderName(it.key).lowercase() }
        if (groups.isEmpty()) return msg("No videos found on this phone.")
        val rows = groups.map { Row(folderName(it.key), "${it.value.size} videos", null, "\uD83D\uDCC1") }
        return withHeader("${groups.size} folders", rowList(rows) { videoFolder = groups[it].key; render() })
    }

    // ---------- audio ----------
    private fun audioPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(strip(listOf("Songs", "Albums", "Artists", "Playlist", "Folders", "Settings"), audioSub) {
            audioSub = it; audioGroup = null; render()
        })
        col.addView(audioBody(), LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun audioBody(): View {
        val g = audioGroup
        if (g != null) {
            val l = songs.filter {
                when (g.first) { 1 -> it.album == g.second; 2 -> it.artist == g.second; else -> it.folder == g.second }
            }
            val name = if (g.first == 4) folderName(g.second) else g.second
            return withHeader("$name - ${l.size} songs", songView(l, false))
        }
        return when (audioSub) {
            0 -> songView(songs, true)
            1 -> groupView(songs.groupBy { it.album }, 1)
            2 -> groupView(songs.groupBy { it.artist }, 2)
            3 -> {
                val fav = Prefs.favs(this)
                val l = songs.filter { fav.contains(it.id.toString()) }
                if (l.isEmpty()) msg("No favourites yet. Tap the heart on the player screen.")
                else withHeader("Favourites - ${l.size} songs", songView(l, false))
            }
            4 -> groupView(songs.groupBy { it.folder }, 4)
            else -> settingsView()
        }
    }

    private fun groupView(map: Map<String, List<Song>>, kind: Int): View {
        val groups = map.entries.sortedBy { it.key.lowercase() }
        if (groups.isEmpty()) return msg("No songs found.")
        val icon = when (kind) { 1 -> "\uD83D\uDCBF"; 2 -> "\uD83D\uDC64"; else -> "\uD83D\uDCC1" }
        val rows = groups.map { Row(if (kind == 4) folderName(it.key) else it.key, "${it.value.size} songs", null, icon) }
        return rowList(rows) { audioGroup = Pair(kind, groups[it].key); render() }
    }

    private fun songView(list: List<Song>, searchBar: Boolean): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val lv = ListView(this)
        styleList(lv)
        var cur = list
        fun setRows(l: List<Song>) {
            cur = l
            lv.adapter = RowAdapter(this, l.map { Row(it.title, fmt(it.durationMs) + "   " + it.artist) })
        }
        setRows(list)
        lv.setOnItemClickListener { _, _, p, _ -> Music.play(this, cur, p) }
        if (searchBar) {
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.setPadding(dp(12), dp(4), dp(12), dp(4))
            val et = EditText(this)
            et.hint = "Search songs (${list.size})"
            et.setHintTextColor(Color.parseColor("#99FFFFFF"))
            et.setTextColor(Color.WHITE)
            et.setSingleLine(true)
            et.background = null
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString()?.trim() ?: ""
                    setRows(if (q.isEmpty()) list else list.filter {
                        it.title.contains(q, true) || it.artist.contains(q, true)
                    })
                }
            })
            val refresh = TextView(this)
            refresh.text = "\u27F3"
            refresh.textSize = 26f
            refresh.setTextColor(Color.WHITE)
            refresh.setPadding(dp(12), 0, dp(12), 0)
            refresh.setOnClickListener { reload() }
            val playAll = TextView(this)
            playAll.text = "\u25B6"
            playAll.textSize = 24f
            playAll.setTextColor(Color.WHITE)
            playAll.setPadding(dp(12), 0, dp(12), 0)
            playAll.setOnClickListener { Music.play(this, cur, 0) }
            bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
            bar.addView(refresh)
            bar.addView(playAll)
            col.addView(bar)
        }
        if (list.isEmpty()) return msg("No songs found.")
        col.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun settingsView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(8))
        fun item(text: String, sub: String): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.VERTICAL
            r.setPadding(0, dp(14), 0, dp(14))
            val t = TextView(this)
            t.text = text
            t.textSize = 17f
            t.setTextColor(Color.WHITE)
            t.setTypeface(null, Typeface.BOLD)
            val s = TextView(this)
            s.text = sub
            s.textSize = 13f
            s.setTextColor(Color.parseColor("#B3FFFFFF"))
            r.addView(t)
            r.addView(s)
            return r
        }
        val sw = Switch(this)
        sw.isChecked = Prefs.hideShort(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setHideShort(this, on); reload() }
        val hs = LinearLayout(this)
        hs.orientation = LinearLayout.HORIZONTAL
        hs.gravity = Gravity.CENTER_VERTICAL
        hs.addView(item("Hide short songs", "Hide songs shorter than 10 seconds"), LinearLayout.LayoutParams(0, -2, 1f))
        hs.addView(sw)
        col.addView(hs)
        val sleep = item("Sleep timer", "Stop the music after some time")
        sleep.setOnClickListener { sleepDialog(this) }
        col.addView(sleep)
        val scan = item("Scan music in storage", "Update missing songs or newly downloaded songs")
        scan.setOnClickListener { reload() }
        col.addView(scan)
        return col
    }

    // ---------- photos ----------
    private fun photoPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(strip(listOf("Photos", "Albums"), photoSub) { photoSub = it; photoAlbum = null; render() })
        val pa = photoAlbum
        val body: View = when {
            pa != null -> withHeader("${folderName(pa)} - ${pics.count { it.folder == pa }} photos", photoGrid(pics.filter { it.folder == pa }))
            photoSub == 0 -> withHeader("${pics.size} photos", photoGrid(pics))
            else -> {
                val groups = pics.groupBy { it.folder }.entries.sortedBy { folderName(it.key).lowercase() }
                if (groups.isEmpty()) msg("No photos found.")
                else rowList(groups.map { Row(folderName(it.key), "${it.value.size} photos", it.value.first().uri) }) {
                    photoAlbum = groups[it].key; render()
                }
            }
        }
        col.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun photoGrid(list: List<Pic>): View {
        if (list.isEmpty()) return msg("No photos found.")
        val gv = GridView(this)
        gv.numColumns = 3
        gv.horizontalSpacing = dp(2)
        gv.verticalSpacing = dp(2)
        gv.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        gv.setBackgroundColor(Color.TRANSPARENT)
        gv.adapter = PhotoAdapter(this, list)
        gv.setOnItemClickListener { _, _, p, _ ->
            Shared.pics = list
            startActivity(Intent(this, PhotoViewerActivity::class.java).putExtra("i", p))
        }
        return gv
    }

    // ---------- mini player ----------
    private fun buildMini(): View {
        mini = LinearLayout(this)
        mini.orientation = LinearLayout.HORIZONTAL
        mini.gravity = Gravity.CENTER_VERTICAL
        mini.setBackgroundColor(Color.parseColor("#E6062F3A"))
        mini.setPadding(dp(12), dp(4), dp(8), dp(4))
        mini.visibility = View.GONE
        val note = TextView(this)
        note.text = "\u266A"
        note.textSize = 24f
        note.setTextColor(Ui.ACCENT)
        miniTitle = TextView(this)
        miniTitle.setTextColor(Color.WHITE)
        miniTitle.textSize = 15f
        miniTitle.setTypeface(null, Typeface.BOLD)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        val prev = iconBtn(this, android.R.drawable.ic_media_previous, 44)
        prev.setOnClickListener { Music.player?.seekToPreviousMediaItem() }
        miniPlay = iconBtn(this, android.R.drawable.ic_media_play, 44)
        miniPlay.setOnClickListener { Music.player?.let { if (it.isPlaying) it.pause() else it.play() } }
        val next = iconBtn(this, android.R.drawable.ic_media_next, 44)
        next.setOnClickListener { Music.player?.seekToNextMediaItem() }
        mini.addView(note)
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        lp.leftMargin = dp(10)
        mini.addView(miniTitle, lp)
        mini.addView(prev)
        mini.addView(miniPlay)
        mini.addView(next)
        mini.setOnClickListener { startActivity(Intent(this, NowPlayingActivity::class.java)) }
        return mini
    }

    private fun updateMini() {
        val s = Music.current()
        if (s == null) { mini.visibility = View.GONE; return }
        mini.visibility = View.VISIBLE
        miniTitle.text = s.title
        val playing = Music.player?.isPlaying == true
        miniPlay.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }
}
