package com.example.videoplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

object Music {
    var player: ExoPlayer? = null
    var queue: List<Song> = emptyList()
    private val listeners = LinkedHashMap<String, () -> Unit>()
    private val h = Handler(Looper.getMainLooper())
    private var sleepRun: Runnable? = null

    fun get(c: Context): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(c.applicationContext).build()
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        p.setHandleAudioBecomingNoisy(true)
        p.addListener(object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) { fire() }
        })
        player = p
        return p
    }

    fun fire() { listeners.values.toList().forEach { it() } }
    fun listen(k: String, f: () -> Unit) { listeners[k] = f }
    fun unlisten(k: String) { listeners.remove(k) }

    fun play(c: Context, songs: List<Song>, index: Int) {
        if (songs.isEmpty()) return
        val p = get(c)
        queue = songs
        p.setMediaItems(songs.map { MediaItem.fromUri(it.uri) }, index, 0L)
        p.prepare()
        p.play()
        val i = Intent(c.applicationContext, MusicService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) c.applicationContext.startForegroundService(i)
            else c.applicationContext.startService(i)
        } catch (e: Throwable) {}
    }

    fun current(): Song? {
        val p = player ?: return null
        return queue.getOrNull(p.currentMediaItemIndex)
    }

    fun sleepIn(minutes: Int) {
        sleepRun?.let { h.removeCallbacks(it) }
        sleepRun = null
        if (minutes > 0) {
            val r = Runnable { player?.pause() }
            sleepRun = r
            h.postDelayed(r, minutes * 60000L)
        }
    }
}

class MusicService : Service() {
    private lateinit var nm: NotificationManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("music", "Music", NotificationManager.IMPORTANCE_LOW))
        }
        Music.listen("svc") { try { nm.notify(1, build()) } catch (e: Throwable) {} }
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val p = Music.player
        when (i?.action) {
            "PP" -> p?.let { if (it.isPlaying) it.pause() else it.play() }
            "NEXT" -> p?.seekToNextMediaItem()
            "PREV" -> p?.seekToPreviousMediaItem()
            "STOP" -> { p?.pause(); stopForeground(true); stopSelf(); return START_NOT_STICKY }
        }
        val n = build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(1, n)
        } catch (e: Throwable) {}
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Music.player?.pause()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        Music.unlisten("svc")
        super.onDestroy()
    }

    private fun act(a: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, MusicService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun action(res: Int, title: String, a: String, code: Int): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, res), title, act(a, code)).build()

    private fun build(): Notification {
        val s = Music.current()
        val playing = Music.player?.isPlaying == true
        val open = PendingIntent.getActivity(this, 0, Intent(this, NowPlayingActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "music") else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play)
        b.setContentTitle(s?.title ?: "Music")
        b.setContentText(s?.artist ?: "")
        b.setContentIntent(open)
        b.setOngoing(playing)
        b.addAction(action(android.R.drawable.ic_media_previous, "Previous", "PREV", 1))
        b.addAction(action(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            if (playing) "Pause" else "Play", "PP", 2))
        b.addAction(action(android.R.drawable.ic_media_next, "Next", "NEXT", 3))
        b.setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        return b.build()
    }
}
