package com.example.videoplayer

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ColorStateList
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.Player

class NowPlayingActivity : Activity() {
    private lateinit var holder: FrameLayout
    private lateinit var art: ImageView
    private lateinit var note: TextView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var playBtn: ImageView
    private lateinit var favBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView
    private var spin: ObjectAnimator? = null
    private var shownId = -1L
    private var dragging = false
    private val h = Handler(Looper.getMainLooper())
    private val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    private val tick = object : Runnable {
        override fun run() { upd(); h.postDelayed(this, 500) }
    }

    private fun txt(t: String, size: Float): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        return tv
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Music.player == null || Music.current() == null) { finish(); return }
        val p = Music.player!!
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.bg()
        root.setPadding(dp(16), dp(8), dp(16), dp(16))

        // top bar
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = txt("\u2304", 30f)
        back.setPadding(dp(8), 0, dp(16), 0)
        back.setOnClickListener { finish() }
        val head = txt("Song", 18f)
        val more = txt("\u22EE", 28f)
        more.setPadding(dp(16), 0, dp(8), 0)
        more.setOnClickListener { menu() }
        top.addView(back)
        top.addView(head, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(more)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(48)))

        // artwork
        val size = resources.displayMetrics.widthPixels - dp(64)
        holder = FrameLayout(this)
        holder.setBackgroundColor(Color.parseColor("#33000000"))
        holder.clipToOutline = true
        holder.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                if (Prefs.shape(this@NowPlayingActivity) == 1) o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat())
                else o.setOval(0, 0, v.width, v.height)
            }
        }
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        note = txt("\u266A", 90f)
        holder.addView(art, FrameLayout.LayoutParams(-1, -1))
        holder.addView(note, FrameLayout.LayoutParams(-1, -1))
        val hl = LinearLayout.LayoutParams(size, size)
        hl.gravity = Gravity.CENTER_HORIZONTAL
        hl.topMargin = dp(24)
        root.addView(holder, hl)
        val a = ObjectAnimator.ofFloat(holder, View.ROTATION, 0f, 360f)
        a.duration = 15000
        a.repeatCount = ObjectAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        spin = a

        // titles
        titleTv = txt("", 20f)
        titleTv.setSingleLine(true)
        titleTv.ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
        titleTv.isSelected = true
        artistTv = txt("", 15f)
        artistTv.setTextColor(Color.parseColor("#B3FFFFFF"))
        artistTv.setSingleLine(true)
        val tl = LinearLayout.LayoutParams(-1, -2)
        tl.topMargin = dp(24)
        root.addView(titleTv, tl)
        root.addView(artistTv, LinearLayout.LayoutParams(-1, -2))

        // small controls row
        val row1 = LinearLayout(this)
        row1.gravity = Gravity.CENTER_VERTICAL
        speedBtn = txt("1.0x", 15f)
        favBtn = txt("\u2661", 28f)
        val sleepBtn = txt("\u23F0", 24f)
        for (v in listOf(speedBtn, favBtn, sleepBtn)) row1.addView(v, LinearLayout.LayoutParams(0, dp(48), 1f))
        speedBtn.setOnClickListener {
            val i = speeds.indexOfFirst { it == p.playbackParameters.speed }
            val n = speeds[(i + 1) % speeds.size]
            p.setPlaybackSpeed(n)
            speedBtn.text = n.toString() + "x"
        }
        favBtn.setOnClickListener { Music.current()?.let { Prefs.toggleFav(this, it.id); sync() } }
        sleepBtn.setOnClickListener { sleepDialog(this) }
        val rl = LinearLayout.LayoutParams(-1, -2)
        rl.topMargin = dp(16)
        root.addView(row1, rl)

        // seek
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        tCur = txt("0:00", 13f)
        tTot = txt("0:00", 13f)
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) tCur.text = fmt(v.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                p.seekTo((s?.progress ?: 0).toLong())
            }
        })
        srow.addView(tCur)
        srow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        srow.addView(tTot)
        root.addView(srow, LinearLayout.LayoutParams(-1, -2))

        // main controls
        val row2 = LinearLayout(this)
        row2.gravity = Gravity.CENTER
        shuffleBtn = txt("\uD83D\uDD00", 24f)
        repeatBtn = txt("\uD83D\uDD01", 24f)
        val prev = iconBtn(this, android.R.drawable.ic_media_previous, 56)
        val next = iconBtn(this, android.R.drawable.ic_media_next, 56)
        playBtn = iconBtn(this, android.R.drawable.ic_media_play, 76)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(Ui.ACCENT)
        playBtn.background = circle
        playBtn.setPadding(dp(20), dp(20), dp(20), dp(20))
        row2.addView(shuffleBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        row2.addView(prev)
        row2.addView(playBtn)
        row2.addView(next)
        row2.addView(repeatBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        shuffleBtn.setOnClickListener { p.shuffleModeEnabled = !p.shuffleModeEnabled; sync() }
        repeatBtn.setOnClickListener {
            p.repeatMode = when (p.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            sync()
        }
        prev.setOnClickListener { p.seekToPreviousMediaItem() }
        next.setOnClickListener { p.seekToNextMediaItem() }
        playBtn.setOnClickListener { if (p.isPlaying) p.pause() else p.play() }
        val cl = LinearLayout.LayoutParams(-1, -2)
        cl.topMargin = dp(16)
        root.addView(row2, cl)
        setContentView(root)
        sync()
    }

    override fun onStart() {
        super.onStart()
        Music.listen("np") { sync() }
        h.post(tick)
        sync()
    }

    override fun onStop() {
        super.onStop()
        Music.unlisten("np")
        h.removeCallbacks(tick)
    }

    override fun onDestroy() {
        spin?.cancel()
        super.onDestroy()
    }

    private fun menu() {
        AlertDialog.Builder(this).setItems(arrayOf("Share", "Shape of image", "Sleep timer")) { _, w ->
            when (w) {
                0 -> Music.current()?.let {
                    val i = Intent(Intent.ACTION_SEND).setType("audio/*")
                        .putExtra(Intent.EXTRA_STREAM, it.uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Share"))
                }
                1 -> AlertDialog.Builder(this).setTitle("Shape of image")
                    .setSingleChoiceItems(
                        arrayOf("Round shape (rotate while playing)", "Square shape", "Round shape (do not rotate)"),
                        Prefs.shape(this)
                    ) { d, which ->
                        Prefs.setShape(this, which)
                        holder.invalidateOutline()
                        sync()
                        d.dismiss()
                    }.show()
                else -> sleepDialog(this)
            }
        }.show()
    }

    private fun sync() {
        val p = Music.player ?: return
        val s = Music.current() ?: return
        if (s.id != shownId) {
            shownId = s.id
            titleTv.text = s.title
            artistTv.text = s.artist
            art.setImageBitmap(null)
            note.visibility = View.VISIBLE
            val id = s.id
            Thread {
                val bmp = try {
                    val m = MediaMetadataRetriever()
                    try {
                        m.setDataSource(this, s.uri)
                        val d = m.embeddedPicture
                        if (d != null) BitmapFactory.decodeByteArray(d, 0, d.size) else null
                    } finally { m.release() }
                } catch (e: Throwable) { null }
                runOnUiThread {
                    if (shownId == id && bmp != null) { art.setImageBitmap(bmp); note.visibility = View.GONE }
                }
            }.start()
        }
        val playing = p.isPlaying
        playBtn.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        favBtn.text = if (Prefs.isFav(this, s.id)) "\u2665" else "\u2661"
        favBtn.setTextColor(if (Prefs.isFav(this, s.id)) Ui.ACCENT else Color.WHITE)
        speedBtn.text = p.playbackParameters.speed.toString() + "x"
        shuffleBtn.alpha = if (p.shuffleModeEnabled) 1f else 0.4f
        repeatBtn.text = if (p.repeatMode == Player.REPEAT_MODE_ONE) "\uD83D\uDD02" else "\uD83D\uDD01"
        repeatBtn.alpha = if (p.repeatMode == Player.REPEAT_MODE_OFF) 0.4f else 1f
        val a = spin!!
        if (Prefs.shape(this) == 0) {
            if (!a.isStarted) a.start()
            if (playing && a.isPaused) a.resume() else if (!playing && !a.isPaused) a.pause()
        } else {
            if (a.isStarted) a.cancel()
            holder.rotation = 0f
        }
        upd()
    }

    private fun upd() {
        val p = Music.player ?: return
        if (dragging) return
        val d = p.duration
        val dur = if (d > 0) d else 0L
        seek.max = dur.toInt()
        seek.progress = p.currentPosition.toInt()
        tCur.text = fmt(p.currentPosition)
        tTot.text = fmt(dur)
    }
}
