package com.example.videoplayer

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs

class PhotoViewerActivity : Activity() {
    private var idx = 0
    private var scale = 1f
    private var token = 0
    private lateinit var iv: ImageView
    private lateinit var label: TextView
    private var list: List<Pic> = emptyList()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        list = Shared.pics
        idx = intent.getIntExtra("i", 0)
        if (list.isEmpty() || idx !in list.indices) { finish(); return }
        val root = GestureFrame(this) { scale <= 1.02f }
        root.setBackgroundColor(Color.BLACK)
        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 14f
        label.setBackgroundColor(Color.parseColor("#66000000"))
        label.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setScale(scale * d.scaleFactor); return true }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean { setScale(if (scale > 1.05f) 1f else 2.5f); return true }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                label.visibility = if (label.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (scale > 1.02f) {
                    val mx = iv.width * (scale - 1f) / 2f
                    val my = iv.height * (scale - 1f) / 2f
                    iv.translationX = (iv.translationX - dx).coerceIn(-mx, mx)
                    iv.translationY = (iv.translationY - dy).coerceIn(-my, my)
                }
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (scale <= 1.02f && abs(vx) > abs(vy) && abs(vx) > 900f) { go(if (vx < 0) 1 else -1); return true }
                return false
            }
        })
        iv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            true
        }
        setContentView(root)
        show()
    }

    private fun setScale(s: Float) {
        scale = s.coerceIn(1f, 5f)
        iv.scaleX = scale
        iv.scaleY = scale
        if (scale <= 1f) { iv.translationX = 0f; iv.translationY = 0f }
    }

    private fun go(d: Int) {
        val n = idx + d
        if (n in list.indices) { idx = n; show() }
    }

    private fun show() {
        setScale(1f)
        val pic = list[idx]
        label.text = "${idx + 1} / ${list.size}   ${pic.name}"
        val my = ++token
        iv.setImageBitmap(null)
        Thread {
            val bmp = decode(pic.uri)
            runOnUiThread { if (my == token && bmp != null) iv.setImageBitmap(bmp) }
        }.start()
    }

    private fun decode(uri: Uri): Bitmap? {
        return try {
            val cr = contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 2048 || o.outHeight / ss > 2048) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val ori = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
            } catch (e: Throwable) { 1 }
            val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            bmp
        } catch (e: Throwable) { null }
    }
}
