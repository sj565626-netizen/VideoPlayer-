package com.example.videoplayer

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private var land = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uris = intent.getStringArrayListExtra("u") ?: arrayListOf()
        val idx = intent.getIntExtra("i", 0)
        if (uris.isEmpty()) { finish(); return }
        val prefs = getSharedPreferences("pos", 0)

        val pv = PlayerView(this)
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        pv.controllerShowTimeoutMs = 3000
        val p = ExoPlayer.Builder(this).build()
        player = p
        pv.player = p
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, idx, prefs.getLong(uris[idx], 0L))
        p.prepare()
        p.playWhenReady = true

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(16, 48, 16, 16)
        val back = Button(this)
        back.text = "Back"
        back.setOnClickListener { finish() }
        val rot = Button(this)
        rot.text = "Rotate"
        rot.setOnClickListener {
            land = !land
            requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                   else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        bar.addView(back)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(rot)

        val root = GestureFrame(this)
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2))
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            bar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onStop() {
        super.onStop()
        player?.let { p ->
            p.currentMediaItem?.localConfiguration?.uri?.toString()?.let {
                getSharedPreferences("pos", 0).edit().putLong(it, p.currentPosition).apply()
            }
            p.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
