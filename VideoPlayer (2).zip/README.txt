Video Player (native Android, Kotlin + Media3)
Tabs: Video | Folder | Audio | Photo
- Audio: Songs / Albums / Artists / Playlist(favourites) / Folders / Settings, mini player, full player screen
- Photo: Photos grid / Albums, full screen viewer (swipe, pinch zoom, double tap)
- Video + Photo viewer: swipe up/down on LEFT half = volume, on RIGHT half = brightness
Build with GitHub Actions (build.yml) or Android Studio: Build > Build APK.
