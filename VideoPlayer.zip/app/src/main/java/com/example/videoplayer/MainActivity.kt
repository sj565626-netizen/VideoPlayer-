package com.example.videoplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {
    private val uris = ArrayList<String>()
    private val names = ArrayList<String>()
    private lateinit var list: ListView
    private lateinit var msg: TextView
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                       else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "Video Player"
        title.textSize = 22f
        title.setPadding(32, 64, 32, 16)
        msg = TextView(this)
        msg.setPadding(32, 8, 32, 16)
        list = ListView(this)
        root.addView(title)
        root.addView(msg)
        root.addView(list, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        list.setOnItemClickListener { _, _, pos, _ ->
            startActivity(
                Intent(this, PlayerActivity::class.java)
                    .putStringArrayListExtra("u", uris)
                    .putExtra("i", pos)
            )
        }
        msg.setOnClickListener { check() }
        check()
    }

    private fun check() {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(perm), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) load()
        else msg.text = "Permission is needed to show your videos. Tap here to allow, or enable it in Settings > Apps > Video Player > Permissions."
    }

    private fun load() {
        uris.clear()
        names.clear()
        val shown = ArrayList<String>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val cols = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
        contentResolver.query(base, cols, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use {
            while (it.moveToNext()) {
                val name = it.getString(1) ?: "Video"
                val s = it.getLong(2) / 1000
                uris.add(ContentUris.withAppendedId(base, it.getLong(0)).toString())
                names.add(name)
                shown.add(name + "\n" + (s / 60) + ":" + (s % 60).toString().padStart(2, '0'))
            }
        }
        msg.text = if (uris.isEmpty()) "No videos found on this phone." else "${uris.size} videos"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown)
    }
}
