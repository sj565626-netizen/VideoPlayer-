Video Player (native Android, Kotlin + Media3)
Tabs: Video | Folder | Audio | Photo
- Audio: Songs / Albums / Artists / Playlist(favourites) / Folders / Settings, mini player, full player screen
- Photo: Photos grid / Albums, full screen viewer (swipe, pinch zoom, double tap)
- Video + Photo viewer: swipe up/down on LEFT half = volume, on RIGHT half = brightness
Build with GitHub Actions (build.yml) or Android Studio: Build > Build APK.

Update:
- Video: real full screen (immersive, notch area), auto-landscape for wide videos, Full screen button, Fit/Fill/Zoom button.
- Audio player: full screen (immersive), landscape supported, Equalizer (EQ button or menu): bands, presets, bass boost, surround.
- Photos: new zoom (pinch around fingers, pan, double tap), Edit button -> filters, brightness/contrast/saturation/warmth, rotate/flip, crop, Save as copy.
- Video player UI redesigned (custom controls): back/title/pop-up(PiP)/menu on top, lock + screenshot on sides,
  seekbar + play/next + speed + rotate + aspect at bottom. Double tap = +-10s / play, drag = seek, swipe = volume/brightness.
- New app icon (res/drawable/ic_launcher.xml).
