package com.example.videoplayer

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Photo editor: 10 filters, brightness / contrast / saturation / warmth,
 * rotate + flip, crop (aspect ratios). "Save" writes a new copy in Pictures/VideoPlayer.
 */
class PhotoEditActivity : Activity() {
    private lateinit var orig: Bitmap
    private var src: Bitmap? = null
    private lateinit var iv: ImageView
    private lateinit var panel: FrameLayout
    private lateinit var tabRow: LinearLayout
    private var panels: List<View> = emptyList()
    private val seeks = ArrayList<SeekBar>()
    private val filterLabels = ArrayList<TextView>()
    private val cropChips = ArrayList<TextView>()

    private var rot = 0
    private var flipH = false
    private var flipV = false
    private var crop = 0
    private var filter = 0
    private val adj = intArrayOf(0, 0, 0, 0) // brightness, contrast, saturation, warmth (-100..100)

    private val filterNames = listOf("Original", "B&W", "Sepia", "Vintage", "Warm", "Cool", "Vivid", "Fade", "Noir", "Negative")
    private val cropNames = listOf("Original", "1:1", "4:3", "3:4", "16:9", "9:16")
    private val cropRatios = floatArrayOf(0f, 1f, 4f / 3f, 3f / 4f, 16f / 9f, 9f / 16f)

    // ------------------------------------------------------------ colour maths

    private fun contrastM(c: Float, b: Float): ColorMatrix {
        val t = 128f * (1f - c) + b
        return ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f))
    }

    private fun filterMatrix(i: Int): ColorMatrix {
        val m = ColorMatrix()
        when (i) {
            1 -> m.setSaturation(0f)
            2 -> m.set(floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f))
            3 -> {
                m.setSaturation(0.6f)
                m.postConcat(ColorMatrix(floatArrayOf(
                    1.1f, 0f, 0f, 0f, 12f,
                    0f, 1.0f, 0f, 0f, 6f,
                    0f, 0f, 0.8f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f)))
            }
            4 -> m.set(floatArrayOf(
                1.15f, 0f, 0f, 0f, 10f,
                0f, 1.05f, 0f, 0f, 0f,
                0f, 0f, 0.85f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f))
            5 -> m.set(floatArrayOf(
                0.88f, 0f, 0f, 0f, 0f,
                0f, 1.0f, 0f, 0f, 4f,
                0f, 0f, 1.18f, 0f, 12f,
                0f, 0f, 0f, 1f, 0f))
            6 -> { m.setSaturation(1.6f); m.postConcat(contrastM(1.15f, 0f)) }
            7 -> { m.setSaturation(0.8f); m.postConcat(contrastM(0.82f, 28f)) }
            8 -> { m.setSaturation(0f); m.postConcat(contrastM(1.45f, -10f)) }
            9 -> m.set(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f))
        }
        return m
    }

    private fun fullMatrix(): ColorMatrix {
        val m = filterMatrix(filter)
        val s = ColorMatrix()
        s.setSaturation(1f + adj[2] / 100f)
        m.postConcat(s)
        m.postConcat(contrastM(1f + adj[1] / 100f * 0.8f, adj[0] * 1.2f))
        val w = adj[3] * 0.35f
        m.postConcat(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, w,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f, -w,
            0f, 0f, 0f, 1f, 0f)))
        return m
    }

    private fun refresh() {
        iv.colorFilter = ColorMatrixColorFilter(fullMatrix())
    }

    // ------------------------------------------------------------ transforms

    private fun rebuild() {
        val m = Matrix()
        if (flipH) m.postScale(-1f, 1f, orig.width / 2f, orig.height / 2f)
        if (flipV) m.postScale(1f, -1f, orig.width / 2f, orig.height / 2f)
        if (rot != 0) m.postRotate(rot * 90f, orig.width / 2f, orig.height / 2f)
        var b = Bitmap.createBitmap(orig, 0, 0, orig.width, orig.height, m, true)
        val ratio = cropRatios[crop]
        if (ratio > 0f) {
            val w = b.width
            val h = b.height
            var cw = w
            var ch = (w / ratio).toInt()
            if (ch > h) { ch = h; cw = (h * ratio).toInt() }
            cw = max(1, cw); ch = max(1, ch)
            b = Bitmap.createBitmap(b, (w - cw) / 2, (h - ch) / 2, cw, ch)
        }
        src = b
        iv.setImageBitmap(b)
        refresh()
    }

    private fun resetAll() {
        rot = 0; flipH = false; flipV = false; crop = 0; filter = 0
        for (i in adj.indices) adj[i] = 0
        for (s in seeks) s.progress = 100
        markFilter(); markCrop()
        rebuild()
    }

    // ------------------------------------------------------------ UI helpers

    private fun chip(t: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(16), dp(10), dp(16), dp(10))
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#33FFFFFF"))
        g.cornerRadius = dp(20).toFloat()
        tv.background = g
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun lp(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(-2, -2)
        l.setMargins(dp(4), dp(4), dp(4), dp(4))
        return l
    }

    private fun markFilter() {
        for (i in filterLabels.indices) filterLabels[i].setTextColor(if (i == filter) Ui.ACCENT else Color.WHITE)
    }

    private fun markCrop() {
        for (i in cropChips.indices) cropChips[i].alpha = if (i == crop) 1f else 0.5f
    }

    private fun filtersPanel(): View {
        val tw = 160
        val sc = tw.toFloat() / min(orig.width, orig.height)
        val thumb = Bitmap.createScaledBitmap(orig, max(1, (orig.width * sc).toInt()), max(1, (orig.height * sc).toInt()), true)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(8), dp(8))
        for (i in filterNames.indices) {
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setImageBitmap(thumb)
            img.colorFilter = ColorMatrixColorFilter(filterMatrix(i))
            val l = TextView(this)
            l.text = filterNames[i]
            l.textSize = 12f
            l.gravity = Gravity.CENTER
            filterLabels.add(l)
            tile.addView(img, LinearLayout.LayoutParams(dp(76), dp(76)))
            tile.addView(l, LinearLayout.LayoutParams(dp(76), -2))
            tile.setOnClickListener { filter = i; markFilter(); refresh() }
            val tp = LinearLayout.LayoutParams(-2, -2)
            tp.setMargins(dp(5), 0, dp(5), 0)
            row.addView(tile, tp)
        }
        markFilter()
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        return hs
    }

    private fun adjustPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(4), dp(16), dp(4))
        val names = arrayOf("Brightness", "Contrast", "Saturation", "Warmth")
        for (i in 0..3) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            val l = TextView(this)
            l.text = names[i]
            l.textSize = 13f
            l.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = 200
            sb.progress = 100 + adj[i]
            sb.progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            sb.thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { adj[i] = v - 100; refresh() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            seeks.add(sb)
            row.addView(l, LinearLayout.LayoutParams(dp(90), -2))
            row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
            col.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        return col
    }

    private fun rotatePanel(): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        row.addView(chip("\u27F2 Left") { rot = (rot + 3) % 4; rebuild() }, lp())
        row.addView(chip("\u27F3 Right") { rot = (rot + 1) % 4; rebuild() }, lp())
        row.addView(chip("\u21C6 Flip H") { flipH = !flipH; rebuild() }, lp())
        row.addView(chip("\u21C5 Flip V") { flipV = !flipV; rebuild() }, lp())
        val hs = HorizontalScrollView(this)
        hs.addView(row, FrameLayout.LayoutParams(-2, -1))
        return hs
    }

    private fun cropPanel(): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        for (i in cropNames.indices) {
            val c = chip(cropNames[i]) { crop = i; markCrop(); rebuild() }
            cropChips.add(c)
            row.addView(c, lp())
        }
        markCrop()
        val hs = HorizontalScrollView(this)
        hs.addView(row, FrameLayout.LayoutParams(-2, -1))
        return hs
    }

    private fun showTab(i: Int) {
        if (panels.isEmpty()) return
        panel.removeAllViews()
        panel.addView(panels[i], FrameLayout.LayoutParams(-1, -1))
        for (k in 0 until tabRow.childCount) {
            (tabRow.getChildAt(k) as TextView).setTextColor(if (k == i) Ui.ACCENT else Color.WHITE)
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val u = intent.getStringExtra("u")
        if (u == null) { finish(); return }
        val uri = Uri.parse(u)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(10), dp(8), dp(6))
        val title = TextView(this)
        title.text = "Edit photo"
        title.textSize = 18f
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(8), 0, 0, 0)
        top.addView(chip("\u2715") { finish() }, lp())
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chip("Reset") { if (src != null) resetAll() }, lp())
        val saveBtn = chip("Save") { save() }
        (saveBtn.background as GradientDrawable).setColor(Ui.ACCENT)
        top.addView(saveBtn, lp())
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(iv, LinearLayout.LayoutParams(-1, 0, 1f))

        panel = FrameLayout(this)
        root.addView(panel, LinearLayout.LayoutParams(-1, dp(150)))

        tabRow = LinearLayout(this)
        val tabNames = listOf("Filters", "Adjust", "Rotate", "Crop")
        for ((i, n) in tabNames.withIndex()) {
            val t = TextView(this)
            t.text = n
            t.textSize = 15f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(14), 0, dp(14))
            t.setOnClickListener { showTab(i) }
            tabRow.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabRow, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        Thread {
            val bmp = decode(uri)
            runOnUiThread {
                if (bmp == null) {
                    Toast.makeText(this, "Photo open nahi ho saki", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    orig = bmp
                    panels = listOf(filtersPanel(), adjustPanel(), rotatePanel(), cropPanel())
                    showTab(0)
                    rebuild()
                }
            }
        }.start()
    }

    private fun decode(uri: Uri): Bitmap? {
        return try {
            val cr = contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 3072 || o.outHeight / ss > 3072) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val ori = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
            } catch (e: Throwable) { 1 }
            val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            bmp
        } catch (e: Throwable) { null }
    }

    // ------------------------------------------------------------ saving

    @Suppress("DEPRECATION")
    private fun save() {
        val b = src ?: return
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 77)
            return
        }
        Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()
        val cm = fullMatrix()
        Thread {
            val ok = try {
                val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
                val p = Paint(Paint.FILTER_BITMAP_FLAG)
                p.colorFilter = ColorMatrixColorFilter(cm)
                Canvas(out).drawBitmap(b, 0f, 0f, p)
                val name = "EDIT_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                write(out, name)
            } catch (e: Throwable) { false }
            runOnUiThread {
                Toast.makeText(this, if (ok) "Saved: Pictures/VideoPlayer" else "Save nahi ho saka", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun write(bmp: Bitmap, name: String): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, name)
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VideoPlayer")
            cv.put(MediaStore.Images.Media.IS_PENDING, 1)
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            val done = contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
            cv.clear()
            cv.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(u, cv, null, null)
            return done
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VideoPlayer")
        dir.mkdirs()
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)))
        return true
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 77 && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) save()
    }
}
