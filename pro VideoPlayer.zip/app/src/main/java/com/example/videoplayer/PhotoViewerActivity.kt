package com.example.videoplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class PhotoViewerActivity : Activity() {
    private var idx = 0
    private var token = 0
    private lateinit var iv: ZoomImageView
    private lateinit var label: TextView
    private lateinit var bottom: LinearLayout
    private var list: List<Pic> = emptyList()

    private fun chip(t: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 16f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(24), dp(12), dp(24), dp(12))
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#88000000"))
        g.cornerRadius = dp(24).toFloat()
        tv.background = g
        tv.setOnClickListener { onClick() }
        return tv
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        list = Shared.pics
        idx = intent.getIntExtra("i", 0)
        if (list.isEmpty() || idx !in list.indices) { finish(); return }
        immersive(true)

        iv = ZoomImageView(this)
        val root = GestureFrame(this) { !iv.zoomed }
        root.setBackgroundColor(Color.BLACK)
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))

        label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 14f
        label.setBackgroundColor(Color.parseColor("#66000000"))
        label.setPadding(dp(28), dp(16), dp(28), dp(12))
        root.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        bottom = LinearLayout(this)
        bottom.gravity = Gravity.CENTER
        bottom.setPadding(dp(16), dp(8), dp(16), dp(24))
        val edit = chip("\u270E  Edit") {
            startActivity(Intent(this, PhotoEditActivity::class.java).putExtra("u", list[idx].uri.toString()))
        }
        val share = chip("Share") {
            val i = Intent(Intent.ACTION_SEND).setType("image/*")
                .putExtra(Intent.EXTRA_STREAM, list[idx].uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share"))
        }
        bottom.addView(edit)
        bottom.addView(View(this), LinearLayout.LayoutParams(dp(16), 1))
        bottom.addView(share)
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        iv.onTap = {
            val v = if (label.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            label.visibility = v
            bottom.visibility = v
        }
        iv.onSwipe = { go(it) }
        setContentView(root)
        show()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) immersive(true)
    }

    private fun go(d: Int) {
        val n = idx + d
        if (n in list.indices) { idx = n; show() }
    }

    private fun show() {
        val pic = list[idx]
        label.text = "${idx + 1} / ${list.size}   ${pic.name}"
        val my = ++token
        iv.setImageBitmap(null)
        Thread {
            val bmp = decode(pic.uri)
            runOnUiThread { if (my == token && bmp != null) iv.setImageBitmap(bmp) }
        }.start()
    }

    private fun decode(uri: Uri): Bitmap? {
        return try {
            val cr = contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 3072 || o.outHeight / ss > 3072) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val ori = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
            } catch (e: Throwable) { 1 }
            val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            bmp
        } catch (e: Throwable) { null }
    }
}
