package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun fmt(ms: Long): String {
    val s = if (ms < 0) 0L else ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun folderName(path: String): String = path.substringAfterLast('/').ifEmpty { "Internal" }

object Ui {
    val ACCENT: Int = Color.parseColor("#F2B228")
    fun bg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#0F6B7C"), Color.parseColor("#062F3A"))
    )
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("app", 0)
    fun hideShort(c: Context) = sp(c).getBoolean("hs", true)
    fun setHideShort(c: Context, v: Boolean) { sp(c).edit().putBoolean("hs", v).apply() }
    fun shape(c: Context) = sp(c).getInt("shape", 0)
    fun setShape(c: Context, v: Int) { sp(c).edit().putInt("shape", v).apply() }
    fun favs(c: Context): Set<String> = HashSet(sp(c).getStringSet("fav", emptySet()) ?: emptySet())
    fun isFav(c: Context, id: Long) = favs(c).contains(id.toString())
    fun toggleFav(c: Context, id: Long): Boolean {
        val s = HashSet(favs(c))
        val now = if (s.contains(id.toString())) { s.remove(id.toString()); false } else { s.add(id.toString()); true }
        sp(c).edit().putStringSet("fav", s).apply()
        return now
    }

    // ---- playlists (custom). Favourites is the built-in one.
    fun playlists(c: Context): List<String> =
        (sp(c).getStringSet("pl_names", emptySet()) ?: emptySet()).sortedBy { it.lowercase() }
    fun playlistIds(c: Context, name: String): Set<String> =
        HashSet(sp(c).getStringSet("pl_$name", emptySet()) ?: emptySet())
    fun createPlaylist(c: Context, name: String) {
        val n = HashSet(sp(c).getStringSet("pl_names", emptySet()) ?: emptySet())
        n.add(name)
        sp(c).edit().putStringSet("pl_names", n).apply()
    }
    fun addToPlaylist(c: Context, name: String, id: Long) {
        val s = HashSet(playlistIds(c, name))
        s.add(id.toString())
        sp(c).edit().putStringSet("pl_$name", s).apply()
    }
    fun deletePlaylist(c: Context, name: String) {
        val n = HashSet(sp(c).getStringSet("pl_names", emptySet()) ?: emptySet())
        n.remove(name)
        sp(c).edit().putStringSet("pl_names", n).remove("pl_$name").apply()
    }

    // ---- photo extras (favourite / hidden / notes)
    private fun set(c: Context, key: String): Set<String> = HashSet(sp(c).getStringSet(key, emptySet()) ?: emptySet())
    fun isPicFav(c: Context, id: Long) = set(c, "pfav").contains(id.toString())
    fun togglePicFav(c: Context, id: Long): Boolean {
        val s = HashSet(set(c, "pfav"))
        val now = if (s.remove(id.toString())) false else { s.add(id.toString()); true }
        sp(c).edit().putStringSet("pfav", s).apply()
        return now
    }
    fun hiddenPics(c: Context): Set<String> = set(c, "phide")
    fun isPicHidden(c: Context, id: Long) = hiddenPics(c).contains(id.toString())
    fun setPicHidden(c: Context, id: Long, hide: Boolean) {
        val s = HashSet(hiddenPics(c))
        if (hide) s.add(id.toString()) else s.remove(id.toString())
        sp(c).edit().putStringSet("phide", s).apply()
    }
    fun picNote(c: Context, id: Long): String = sp(c).getString("pnote_$id", "") ?: ""
    fun setPicNote(c: Context, id: Long, t: String) {
        if (t.isBlank()) sp(c).edit().remove("pnote_$id").apply() else sp(c).edit().putString("pnote_$id", t.trim()).apply()
    }
}

object Shared {
    var pics: List<Pic> = emptyList()
    /** set when files were deleted / renamed / copied / moved so the lists reload */
    var dirty = false
    /** all photo folders (full paths), used by Move / Copy */
    var folders: List<String> = emptyList()
}

data class Vid(val id: Long, val name: String, val folder: String, val durationMs: Long, val uri: Uri)
data class Song(val id: Long, val title: String, val artist: String, val album: String, val folder: String, val durationMs: Long, val uri: Uri)
data class Pic(val id: Long, val name: String, val folder: String, val dateSec: Long, val uri: Uri)

object Repo {
    private fun parent(path: String): String = path.substringBeforeLast('/', "")

    fun videos(c: Context): List<Vid> {
        val out = ArrayList<Vid>()
        try {
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val cols = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA)
            c.contentResolver.query(base, cols, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use {
                while (it.moveToNext()) {
                    out.add(Vid(it.getLong(0), it.getString(1) ?: "Video", parent(it.getString(3) ?: ""),
                        it.getLong(2), ContentUris.withAppendedId(base, it.getLong(0))))
                }
            }
        } catch (e: Throwable) {}
        return out
    }

    fun songs(c: Context): List<Song> {
        val out = ArrayList<Song>()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA)
            val minMs = if (Prefs.hideShort(c)) 10000 else 1
            c.contentResolver.query(base, cols, MediaStore.Audio.Media.DURATION + " >= " + minMs, null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use {
                while (it.moveToNext()) {
                    out.add(Song(it.getLong(0), it.getString(1) ?: "Unknown", it.getString(2) ?: "<unknown>",
                        it.getString(3) ?: "<unknown>", parent(it.getString(5) ?: ""), it.getLong(4),
                        ContentUris.withAppendedId(base, it.getLong(0))))
                }
            }
        } catch (e: Throwable) {}
        return out
    }

    fun pics(c: Context): List<Pic> {
        val out = ArrayList<Pic>()
        try {
            val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val cols = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATA, MediaStore.Images.Media.DATE_TAKEN)
            c.contentResolver.query(base, cols, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")?.use {
                while (it.moveToNext()) {
                    val taken = it.getLong(4)
                    out.add(Pic(it.getLong(0), it.getString(1) ?: "Photo", parent(it.getString(3) ?: ""),
                        if (taken > 0) taken / 1000 else it.getLong(2), ContentUris.withAppendedId(base, it.getLong(0))))
                }
            }
        } catch (e: Throwable) {}
        return out
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(40 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(c: Context, iv: ImageView, uri: Uri, size: Int) {
        val key = uri.toString()
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageBitmap(null)
        val app = c.applicationContext
        pool.execute {
            val bmp = try { make(app, uri, size) } catch (e: Throwable) { null }
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun make(c: Context, uri: Uri, size: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) return c.contentResolver.loadThumbnail(uri, Size(size, size), null)
        val id = ContentUris.parseId(uri)
        return if (uri.toString().contains("/video/"))
            MediaStore.Video.Thumbnails.getThumbnail(c.contentResolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null)
        else
            MediaStore.Images.Thumbnails.getThumbnail(c.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
    }
}

class SquareImageView(c: Context) : ImageView(c) {
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, w) }
}

class Row(val title: String, val sub: String, val thumb: Uri? = null, val icon: String = "\u266A")

class RowAdapter(private val c: Context, private val rows: List<Row>) : BaseAdapter() {
    private class Holder(val iv: ImageView, val ic: TextView, val t: TextView, val s: TextView)

    override fun getCount() = rows.size
    override fun getItem(p: Int): Any = rows[p]
    override fun getItemId(p: Int) = p.toLong()

    override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
        val v: View
        val h: Holder
        if (cv == null) {
            val root = LinearLayout(c)
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(c.dp(12), c.dp(8), c.dp(12), c.dp(8))
            val box = FrameLayout(c)
            box.setBackgroundColor(Color.parseColor("#33FFFFFF"))
            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            val ic = TextView(c)
            ic.gravity = Gravity.CENTER
            ic.textSize = 26f
            ic.setTextColor(Color.WHITE)
            box.addView(iv, FrameLayout.LayoutParams(-1, -1))
            box.addView(ic, FrameLayout.LayoutParams(-1, -1))
            root.addView(box, LinearLayout.LayoutParams(c.dp(56), c.dp(56)))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            val t = TextView(c)
            t.textSize = 16f
            t.setTextColor(Color.WHITE)
            t.setTypeface(null, Typeface.BOLD)
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            val s = TextView(c)
            s.textSize = 13f
            s.setTextColor(Color.parseColor("#B3FFFFFF"))
            s.maxLines = 1
            s.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(t)
            col.addView(s)
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            lp.leftMargin = c.dp(12)
            root.addView(col, lp)
            h = Holder(iv, ic, t, s)
            root.tag = h
            v = root
        } else {
            v = cv
            h = cv.tag as Holder
        }
        val r = rows[p]
        h.t.text = r.title
        h.s.text = r.sub
        if (r.thumb != null) {
            h.ic.visibility = View.GONE
            h.iv.visibility = View.VISIBLE
            Thumbs.load(c, h.iv, r.thumb, 160)
        } else {
            h.iv.tag = null
            h.iv.setImageBitmap(null)
            h.iv.visibility = View.GONE
            h.ic.visibility = View.VISIBLE
            h.ic.text = r.icon
        }
        return v
    }
}

class PhotoAdapter(private val c: Context, private val list: List<Pic>) : BaseAdapter() {
    override fun getCount() = list.size
    override fun getItem(p: Int): Any = list[p]
    override fun getItemId(p: Int) = p.toLong()
    override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
        val iv = (cv as? SquareImageView) ?: SquareImageView(c).also {
            it.scaleType = ImageView.ScaleType.CENTER_CROP
            it.setBackgroundColor(Color.parseColor("#33000000"))
        }
        Thumbs.load(c, iv, list[p].uri, 300)
        return iv
    }
}

fun iconBtn(c: Context, res: Int, sizeDp: Int): ImageView {
    val iv = ImageView(c)
    iv.setImageResource(res)
    iv.setColorFilter(Color.WHITE)
    val pad = c.dp(sizeDp / 4)
    iv.setPadding(pad, pad, pad, pad)
    iv.layoutParams = LinearLayout.LayoutParams(c.dp(sizeDp), c.dp(sizeDp))
    return iv
}

fun sleepDialog(a: Activity) {
    val mins = intArrayOf(0, 15, 30, 45, 60)
    AlertDialog.Builder(a).setTitle("Sleep timer")
        .setItems(arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes")) { _, w ->
            Music.sleepIn(mins[w])
            Toast.makeText(a, if (mins[w] == 0) "Sleep timer off" else "Music will stop in ${mins[w]} min", Toast.LENGTH_SHORT).show()
        }.show()
}

/**
 * Swipe up/down on the LEFT half = volume, on the RIGHT half = brightness.
 * Taps and horizontal gestures still go to the child views.
 */
class GestureFrame(private val act: Activity, private val canUse: () -> Boolean = { true }) : FrameLayout(act) {
    private val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val slop = ViewConfiguration.get(act).scaledTouchSlop
    private val info = TextView(act)
    private val hideRun = Runnable { info.visibility = View.GONE }
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var mode = 0
    private var vol = 0f
    private var bri = 0.5f

    init {
        info.textSize = 22f
        info.setTextColor(Color.WHITE)
        info.gravity = Gravity.CENTER
        info.setPadding(act.dp(20), act.dp(14), act.dp(20), act.dp(14))
        val bgd = GradientDrawable()
        bgd.setColor(Color.parseColor("#AA000000"))
        bgd.cornerRadius = act.dp(16).toFloat()
        info.background = bgd
        info.visibility = View.GONE
        addView(info, LayoutParams(-2, -2, Gravity.CENTER))
    }

    private fun curBrightness(): Float {
        val b = act.window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) { 0.5f }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; lastY = ev.y; mode = 0 }
            MotionEvent.ACTION_MOVE -> if (mode == 0 && ev.pointerCount == 1 && canUse()) {
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (abs(dy) > slop * 2 && abs(dy) > abs(dx) * 1.5f && downY > height * 0.12f && downY < height * 0.80f) {
                    mode = if (downX < width / 2f) 1 else 2
                    lastY = ev.y
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    bri = curBrightness()
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (mode == 0) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val delta = (lastY - ev.y) / (height * 0.7f)
                lastY = ev.y
                if (mode == 1) {
                    vol = (vol + delta).coerceIn(0f, 1f)
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (vol * max).roundToInt(), 0)
                    show("Volume  " + (vol * 100).roundToInt() + "%")
                } else {
                    bri = (bri + delta).coerceIn(0.02f, 1f)
                    val lp = act.window.attributes
                    lp.screenBrightness = bri
                    act.window.attributes = lp
                    show("Brightness  " + (bri * 100).roundToInt() + "%")
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = 0
                info.removeCallbacks(hideRun)
                info.postDelayed(hideRun, 700)
            }
        }
        return true
    }

    private fun show(t: String) {
        info.text = t
        info.visibility = View.VISIBLE
        info.bringToFront()
        info.removeCallbacks(hideRun)
    }
}
