package com.example.videoplayer

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Player
import java.io.File
import java.io.FileOutputStream

class NowPlayingActivity : Activity() {
    private lateinit var holder: FrameLayout
    private lateinit var art: ImageView
    private lateinit var bgImg: ImageView
    private lateinit var note: TextView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var queueTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var playBtn: ImageView
    private lateinit var favBtn: ImageView
    private lateinit var speedTv: TextView
    private lateinit var shuffleBtn: ImageView
    private lateinit var repeatBtn: ImageView
    private var spin: ObjectAnimator? = null
    private var shownId = -1L
    private var dragging = false
    private val h = Handler(Looper.getMainLooper())
    private val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    private val access = Access(this, 41)
    private val REQ_PICK = 40
    private val tick = object : Runnable {
        override fun run() { upd(); h.postDelayed(this, 500) }
    }

    private fun txt(t: String, size: Float, color: Int = Color.WHITE): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        tv.gravity = Gravity.CENTER
        return tv
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    /** one equally-sized icon button of a control row */
    private fun cell(icon: ImageView, onClick: () -> Unit): View {
        val box = FrameLayout(this)
        val lp = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
        icon.layoutParams = lp
        box.addView(icon)
        box.setOnClickListener { onClick() }
        box.layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
        return box
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Music.player == null || Music.current() == null) { finish(); return }
        val p = Music.player!!
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        // ---------------------------------------------------------- background layers
        val frame = FrameLayout(this)
        frame.background = Ui.bg()
        bgImg = ImageView(this)
        bgImg.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImg.visibility = View.GONE
        frame.addView(bgImg, FrameLayout.LayoutParams(-1, -1))
        val scrim = View(this)
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#8C000000"), Color.parseColor("#47000000"), Color.parseColor("#D9000000")))
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        // ---------------------------------------------------------- top bar
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = tintedIcon(R.drawable.ic_chevron_down, 52, Color.WHITE, 12)
        back.setOnClickListener { finish() }
        val qBox = LinearLayout(this)
        qBox.orientation = LinearLayout.VERTICAL
        qBox.gravity = Gravity.CENTER
        qBox.setPadding(dp(14), 0, dp(14), 0)
        qBox.addView(tintedIcon(R.drawable.ic_queue, 24))
        queueTv = txt("#1/1", 11f, Color.parseColor("#CCFFFFFF"))
        qBox.addView(queueTv)
        qBox.setOnClickListener { queueDialog() }
        val more = tintedIcon(R.drawable.ic_more, 52, Color.WHITE, 14)
        more.setOnClickListener { menu(more) }
        top.addView(back)
        top.addView(qBox, LinearLayout.LayoutParams(-2, -1))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(more)

        // ---------------------------------------------------------- artwork (always fits the free space)
        val artBox = SquareFit(this)
        val pad = dp(if (land) 12 else 22)
        artBox.setPadding(pad, dp(6), pad, dp(6))
        holder = FrameLayout(this)
        holder.setBackgroundColor(Color.parseColor("#33000000"))
        holder.clipToOutline = true
        holder.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                if (Prefs.shape(this@NowPlayingActivity) == 1) o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat())
                else o.setOval(0, 0, v.width, v.height)
            }
        }
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        note = txt("♪", 90f)
        holder.addView(art, FrameLayout.LayoutParams(-1, -1))
        holder.addView(note, FrameLayout.LayoutParams(-1, -1))
        artBox.addView(holder)
        val a = ObjectAnimator.ofFloat(holder, View.ROTATION, 0f, 360f)
        a.duration = 15000
        a.repeatCount = ObjectAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        spin = a

        // ---------------------------------------------------------- controls block
        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setPadding(dp(14), 0, dp(14), dp(10))

        titleTv = txt("", 20f)
        titleTv.setTypeface(null, android.graphics.Typeface.BOLD)
        titleTv.setSingleLine(true)
        titleTv.ellipsize = TextUtils.TruncateAt.MARQUEE
        titleTv.marqueeRepeatLimit = -1
        titleTv.isSelected = true
        titleTv.setPadding(dp(8), 0, dp(8), 0)
        artistTv = txt("", 16f, Color.parseColor("#CCFFFFFF"))
        artistTv.setSingleLine(true)
        artistTv.ellipsize = TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(-1, -2)
        tl.topMargin = dp(10)
        controls.addView(titleTv, tl)
        controls.addView(artistTv, LinearLayout.LayoutParams(-1, -2))

        // row 1: speed | equalizer | favourite | add to playlist | sleep timer | volume
        val row1 = LinearLayout(this)
        row1.gravity = Gravity.CENTER_VERTICAL
        val speedBox = LinearLayout(this)
        speedBox.orientation = LinearLayout.VERTICAL
        speedBox.gravity = Gravity.CENTER
        speedBox.addView(tintedIcon(R.drawable.ic_speed, 24))
        speedTv = txt("1.0", 10f)
        speedBox.addView(speedTv)
        speedBox.setOnClickListener {
            val i = speeds.indexOfFirst { it == p.playbackParameters.speed }
            p.setPlaybackSpeed(speeds[(i + 1) % speeds.size])
            sync()
        }
        speedBox.layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
        favBtn = tintedIcon(R.drawable.ic_fav_off, 26)
        row1.addView(speedBox)
        row1.addView(cell(tintedIcon(R.drawable.ic_eq, 26)) { eqDialog(this) })
        row1.addView(cell(favBtn) { Music.current()?.let { Prefs.toggleFav(this, it.id); sync() } })
        row1.addView(cell(tintedIcon(R.drawable.ic_playlist_add, 26)) { playlistDialog() })
        row1.addView(cell(tintedIcon(R.drawable.ic_alarm, 26)) { sleepDialog(this) })
        row1.addView(cell(tintedIcon(R.drawable.ic_volume, 26)) {
            (getSystemService(AUDIO_SERVICE) as AudioManager)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
        })
        val rl = LinearLayout.LayoutParams(-1, -2)
        rl.topMargin = dp(6)
        controls.addView(row1, rl)

        // seek row
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        tCur = txt("0:00", 13f)
        tTot = txt("0:00", 13f)
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#66FFFFFF"))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) tCur.text = fmt(v.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                p.seekTo((s?.progress ?: 0).toLong())
            }
        })
        tCur.minWidth = dp(44)
        tTot.minWidth = dp(44)
        srow.addView(tCur)
        srow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        srow.addView(tTot)
        controls.addView(srow, LinearLayout.LayoutParams(-1, -2))

        // main controls: shuffle | previous | play | next | repeat
        val row2 = LinearLayout(this)
        row2.gravity = Gravity.CENTER
        shuffleBtn = tintedIcon(R.drawable.ic_shuffle, 26)
        repeatBtn = tintedIcon(R.drawable.ic_repeat, 26)
        val prev = tintedIcon(R.drawable.ic_prev, 56, Color.WHITE, 12)
        val next = tintedIcon(R.drawable.ic_next, 56, Color.WHITE, 12)
        playBtn = tintedIcon(R.drawable.ic_play, 72, Color.WHITE, 18)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(Ui.ACCENT)
        playBtn.background = circle
        row2.addView(cell(shuffleBtn) { p.shuffleModeEnabled = !p.shuffleModeEnabled; sync() })
        row2.addView(prev)
        row2.addView(playBtn, (playBtn.layoutParams as LinearLayout.LayoutParams).also {
            it.leftMargin = dp(8); it.rightMargin = dp(8)
        })
        row2.addView(next)
        row2.addView(cell(repeatBtn) {
            p.repeatMode = when (p.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            sync()
        })
        prev.setOnClickListener { p.seekToPreviousMediaItem() }
        next.setOnClickListener { p.seekToNextMediaItem() }
        playBtn.setOnClickListener { if (p.isPlaying) p.pause() else p.play() }
        val cl = LinearLayout.LayoutParams(-1, -2)
        cl.topMargin = dp(4)
        controls.addView(row2, cl)

        // ---------------------------------------------------------- arrange (portrait / landscape)
        val content = LinearLayout(this)
        if (!land) {
            content.orientation = LinearLayout.VERTICAL
            content.addView(top, LinearLayout.LayoutParams(-1, dp(56)))
            content.addView(artBox, LinearLayout.LayoutParams(-1, 0, 1f))
            content.addView(controls, LinearLayout.LayoutParams(-1, -2))
        } else {
            content.orientation = LinearLayout.HORIZONTAL
            content.addView(artBox, LinearLayout.LayoutParams(0, -1, 1f))
            val right = LinearLayout(this)
            right.orientation = LinearLayout.VERTICAL
            right.addView(top, LinearLayout.LayoutParams(-1, dp(56)))
            right.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
            right.addView(controls, LinearLayout.LayoutParams(-1, -2))
            content.addView(right, LinearLayout.LayoutParams(0, -1, 1f))
        }
        frame.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        edgeToEdge(content)
        sync()
    }

    override fun onStart() {
        super.onStart()
        if (!::seek.isInitialized) return
        Music.listen("np") { sync() }
        h.post(tick)
        sync()
    }

    override fun onStop() {
        super.onStop()
        Music.unlisten("np")
        h.removeCallbacks(tick)
    }

    override fun onDestroy() {
        spin?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ menu (same options as the reference)

    private fun menu(anchor: View) {
        val s = Music.current() ?: return
        val sh = Prefs.shape(this)
        val items = listOf(
            PM("Go to", "Album, Artist, Folder", R.drawable.ic_album, click = { goTo() }),
            PM("Change cover photo", null, R.drawable.ic_label, click = { changeCover() }),
            PM("Use as ringtone", null, R.drawable.ic_bell, click = { ringtone() }),
            PM("Share", null, R.drawable.ic_share, click = { share() }),
            PM("Delete", "Put it in the trash", R.drawable.ic_delete, click = { confirmDelete() }),
            PM("Shape of image", null, R.drawable.ic_settings, divider = false),
            PM("Round shape", "rotate while playing", selected = sh == 0, divider = false, click = { setShape(0) }),
            PM("Square shape", null, selected = sh == 1, divider = false, click = { setShape(1) }),
            PM("Round shape", "do not rotate", selected = sh == 2, click = { setShape(2) }),
            PM(s.title, null, R.drawable.ic_info, Color.parseColor("#1BB5A6"), divider = false, click = { info() })
        )
        PopMenu.show(this, anchor, items, dark = false, above = false, widthDp = 290)
    }

    private fun setShape(i: Int) {
        Prefs.setShape(this, i)
        holder.invalidateOutline()
        sync()
    }

    private fun goTo() {
        val s = Music.current() ?: return
        val labels = arrayOf("Album:  " + s.album, "Artist:  " + s.artist, "Folder:  " + folderName(s.folder))
        AlertDialog.Builder(this).setTitle("Go to").setItems(labels) { _, w ->
            val kind = when (w) { 0 -> 1; 1 -> 2; else -> 4 }
            val key = when (w) { 0 -> s.album; 1 -> s.artist; else -> s.folder }
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("goKind", kind).putExtra("goKey", key))
            finish()
        }.show()
    }

    // ---- custom cover photo
    private fun coverFile(id: Long) = File(File(filesDir, "covers"), "$id.jpg")

    private fun changeCover() {
        val s = Music.current() ?: return
        if (coverFile(s.id).exists()) {
            AlertDialog.Builder(this).setTitle("Cover photo")
                .setItems(arrayOf("Choose new photo", "Remove custom cover")) { _, w ->
                    if (w == 0) pickCover() else { coverFile(s.id).delete(); shownId = -1; sync() }
                }.show()
        } else pickCover()
    }

    private fun pickCover() {
        try {
            startActivityForResult(
                Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_PICK)
        } catch (e: Throwable) { toast("No gallery app found") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (access.onResult(req, res)) return
        if (req == REQ_PICK && res == RESULT_OK) {
            val u = data?.data ?: return
            val s = Music.current() ?: return
            Thread {
                val ok = saveCover(u, s.id)
                runOnUiThread {
                    if (ok) { shownId = -1; sync(); toast("Cover photo changed") } else toast("Could not open this photo")
                }
            }.start()
        }
    }

    private fun saveCover(u: Uri, id: Long): Boolean {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 1600 || o.outHeight / ss > 1600) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
            val f = coverFile(id)
            f.parentFile?.mkdirs()
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Throwable) { false }
    }

    // ---- ringtone
    private fun ringtone() {
        val s = Music.current() ?: return
        if (!Settings.System.canWrite(this)) {
            toast("Allow \"Modify system settings\" for this app, then choose Use as ringtone again")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(Uri.parse("package:$packageName")))
            } catch (e: Throwable) {}
            return
        }
        try {
            RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, s.uri)
            toast("Ringtone set: " + s.title)
        } catch (e: Throwable) { toast("Could not set the ringtone") }
    }

    private fun share() {
        Music.current()?.let {
            val i = Intent(Intent.ACTION_SEND).setType("audio/*")
                .putExtra(Intent.EXTRA_STREAM, it.uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share"))
        }
    }

    // ---- delete (trash)
    private fun confirmDelete() {
        val s = Music.current() ?: return
        val trash = Build.VERSION.SDK_INT >= 30
        AlertDialog.Builder(this)
            .setTitle(if (trash) "Move to trash?" else "Delete song?")
            .setMessage(s.title)
            .setPositiveButton("Delete") { _, _ -> deleteSong(s) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteSong(s: Song) {
        val idx = Music.queue.indexOfFirst { it.id == s.id }
        access.run(0, s.uri,
            op = { if (contentResolver.delete(s.uri, null, null) < 1) throw IllegalStateException("not deleted") },
            ui = {
                Shared.dirty = true
                if (idx >= 0) Music.removeAt(idx)
                toast("Deleted: " + s.title)
                if (Music.queue.isEmpty()) finish() else sync()
            })
    }

    // ---- info
    private fun info() {
        val s = Music.current() ?: return
        var size = "-"
        var mime = "-"
        try {
            contentResolver.query(s.uri, arrayOf(MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE),
                null, null, null)?.use {
                if (it.moveToFirst()) { size = fmtSize(it.getLong(0)); mime = it.getString(1) ?: "-" }
            }
        } catch (e: Throwable) {}
        val msg = "Title:  ${s.title}\nArtist:  ${s.artist}\nAlbum:  ${s.album}\nDuration:  ${fmt(s.durationMs)}\n" +
            "Format:  $mime\nSize:  $size\nFolder:  ${s.folder}"
        AlertDialog.Builder(this).setTitle("Song info").setMessage(msg).setPositiveButton("Close", null).show()
    }

    // ---- queue + playlists
    private fun queueDialog() {
        val p = Music.player ?: return
        val q = Music.queue
        AlertDialog.Builder(this).setTitle("Playing queue (${q.size})")
            .setSingleChoiceItems(q.map { it.title }.toTypedArray(), p.currentMediaItemIndex) { d, w ->
                p.seekTo(w, 0L)
                p.play()
                d.dismiss()
            }.show()
    }

    private fun playlistDialog() {
        val s = Music.current() ?: return
        val names = Prefs.playlists(this)
        val items = ArrayList<String>()
        items.add("♥  Favourites")
        items.addAll(names)
        items.add("+  New playlist")
        AlertDialog.Builder(this).setTitle("Add to playlist").setItems(items.toTypedArray()) { _, w ->
            when {
                w == 0 -> {
                    if (!Prefs.isFav(this, s.id)) Prefs.toggleFav(this, s.id)
                    toast("Added to Favourites")
                    sync()
                }
                w == items.size - 1 -> newPlaylist(s)
                else -> { Prefs.addToPlaylist(this, names[w - 1], s.id); toast("Added to " + names[w - 1]) }
            }
        }.show()
    }

    private fun newPlaylist(s: Song) {
        val et = EditText(this)
        et.hint = "Playlist name"
        et.setSingleLine(true)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("New playlist").setView(box)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    Prefs.createPlaylist(this, n)
                    Prefs.addToPlaylist(this, n, s.id)
                    toast("Added to $n")
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ cover / state

    private fun decodeBytes(d: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(d, 0, d.size, o)
        var ss = 1
        while (o.outWidth / ss > 1400 || o.outHeight / ss > 1400) ss *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = ss
        return BitmapFactory.decodeByteArray(d, 0, d.size, o2)
    }

    private fun loadCover(s: Song): Bitmap? {
        try {
            val f = coverFile(s.id)
            if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it }
        } catch (e: Throwable) {}
        try {
            val m = MediaMetadataRetriever()
            try {
                m.setDataSource(this, s.uri)
                val d = m.embeddedPicture
                if (d != null) decodeBytes(d)?.let { return it }
            } finally { m.release() }
        } catch (e: Throwable) {}
        if (Build.VERSION.SDK_INT >= 29) {
            try { return contentResolver.loadThumbnail(s.uri, Size(800, 800), null) } catch (e: Throwable) {}
        }
        return null
    }

    /** soft blurred copy of the cover as the screen background */
    private fun backdrop(bmp: Bitmap) {
        try {
            var w = bmp.width
            var hh = bmp.height
            var cur = bmp
            while (w > 48) {
                w /= 2
                hh = (hh / 2).coerceAtLeast(1)
                cur = Bitmap.createScaledBitmap(cur, w.coerceAtLeast(1), hh, true)
            }
            bgImg.setImageBitmap(cur)
            bgImg.visibility = View.VISIBLE
        } catch (e: Throwable) { bgImg.visibility = View.GONE }
    }

    private fun sync() {
        val p = Music.player ?: return
        val s = Music.current() ?: return
        queueTv.text = "#${p.currentMediaItemIndex + 1}/${Music.queue.size}"
        if (s.id != shownId) {
            shownId = s.id
            titleTv.text = s.title
            artistTv.text = s.artist
            art.setImageBitmap(null)
            bgImg.visibility = View.GONE
            note.visibility = View.VISIBLE
            val id = s.id
            Thread {
                val bmp = loadCover(s)
                runOnUiThread {
                    if (shownId == id && bmp != null) {
                        art.setImageBitmap(bmp)
                        note.visibility = View.GONE
                        backdrop(bmp)
                    }
                }
            }.start()
        }
        val playing = p.isPlaying
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        val fav = Prefs.isFav(this, s.id)
        favBtn.setImageResource(if (fav) R.drawable.ic_fav_on else R.drawable.ic_fav_off)
        favBtn.setColorFilter(if (fav) Ui.ACCENT else Color.WHITE)
        speedTv.text = p.playbackParameters.speed.toString()
        shuffleBtn.alpha = if (p.shuffleModeEnabled) 1f else 0.45f
        shuffleBtn.setColorFilter(if (p.shuffleModeEnabled) Ui.ACCENT else Color.WHITE)
        repeatBtn.setImageResource(if (p.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatBtn.alpha = if (p.repeatMode == Player.REPEAT_MODE_OFF) 0.45f else 1f
        repeatBtn.setColorFilter(if (p.repeatMode == Player.REPEAT_MODE_OFF) Color.WHITE else Ui.ACCENT)
        val a = spin!!
        if (Prefs.shape(this) == 0) {
            if (!a.isStarted) a.start()
            if (playing && a.isPaused) a.resume() else if (!playing && !a.isPaused) a.pause()
        } else {
            if (a.isStarted) a.cancel()
            holder.rotation = 0f
        }
        upd()
    }

    private fun upd() {
        val p = Music.player ?: return
        if (dragging) return
        val d = p.duration
        val dur = if (d > 0) d else 0L
        seek.max = dur.toInt()
        seek.progress = p.currentPosition.toInt()
        tCur.text = fmt(p.currentPosition)
        tTot.text = fmt(dur)
    }
}
