package com.example.videoplayer

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Toast
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

// ------------------------------------------------------------------ small helpers

fun Context.tintedIcon(res: Int, sizeDp: Int = 24, color: Int = Color.WHITE, padDp: Int = 0): ImageView {
    val iv = ImageView(this)
    iv.setImageResource(res)
    iv.setColorFilter(color)
    iv.scaleType = ImageView.ScaleType.FIT_CENTER
    val p = dp(padDp)
    iv.setPadding(p, p, p, p)
    iv.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    return iv
}

/**
 * Edge-to-edge window: content draws behind transparent status/navigation bars and [content]
 * receives the system-bar (and notch) insets as padding, so nothing is ever cut off.
 */
@Suppress("DEPRECATION")
fun Activity.edgeToEdge(content: View, onInsets: ((Int, Int, Int, Int) -> Unit)? = null) {
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
    window.statusBarColor = Color.TRANSPARENT
    window.navigationBarColor = Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    if (Build.VERSION.SDK_INT >= 30) {
        window.setDecorFitsSystemWindows(false)
        content.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            if (onInsets != null) onInsets(b.left, b.top, b.right, b.bottom) else v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
    } else {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        content.setOnApplyWindowInsetsListener { v, ins ->
            if (onInsets != null) onInsets(ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            else v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins.consumeSystemWindowInsets()
        }
    }
    content.requestApplyInsets()
}

/** Show / hide the status + navigation bars (swipe from the edge brings them back temporarily). */
@Suppress("DEPRECATION")
fun Activity.systemBars(show: Boolean) {
    if (Build.VERSION.SDK_INT >= 30) {
        val c = window.insetsController ?: return
        if (show) c.show(WindowInsets.Type.systemBars())
        else {
            c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsets.Type.systemBars())
        }
    } else {
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (!show) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = f
    }
}

/** Square child, as large as possible, centred in whatever space is left (keeps cover art fully on screen). */
class SquareFit(c: Context) : FrameLayout(c) {
    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w)
        val hh = MeasureSpec.getSize(h)
        setMeasuredDimension(ww, hh)
        val s = min(ww - paddingLeft - paddingRight, hh - paddingTop - paddingBottom).coerceAtLeast(0)
        for (i in 0 until childCount) {
            getChildAt(i).measure(MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val x = (r - l - v.measuredWidth) / 2
            val y = (b - t - v.measuredHeight) / 2
            v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
        }
    }
}

// ------------------------------------------------------------------ popup menu

class PM(
    val title: String,
    val sub: String? = null,
    val icon: Int = 0,
    val iconColor: Int = Color.parseColor("#F26B38"),
    val selected: Boolean = false,
    val divider: Boolean = true,
    val click: (() -> Unit)? = null
)

object PopMenu {
    private val ORANGE = Color.parseColor("#F26B38")

    /**
     * [dark] = dark grey gallery style (text only), otherwise white card style with round coloured icons.
     * [above] = open upwards from the anchor (bottom bar), otherwise downwards (top bar).
     */
    fun show(a: Activity, anchor: View, items: List<PM>, dark: Boolean, above: Boolean, widthDp: Int): PopupWindow {
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(if (dark) Color.parseColor("#F2323234") else Color.WHITE)
        bg.cornerRadius = a.dp(if (dark) 14 else 6).toFloat()
        col.background = bg
        col.setPadding(0, a.dp(4), 0, a.dp(4))

        var win: PopupWindow? = null
        for (item in items) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = a.dp(if (dark) 52 else 56)
            row.setPadding(a.dp(16), a.dp(8), a.dp(16), a.dp(8))
            if (item.icon != 0) {
                val circle = FrameLayout(a)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setStroke(a.dp(2), item.iconColor)
                g.setColor(Color.WHITE)
                circle.background = g
                val ic = a.tintedIcon(item.icon, 22, item.iconColor)
                val lp = FrameLayout.LayoutParams(a.dp(22), a.dp(22), Gravity.CENTER)
                circle.addView(ic, lp)
                val cl = LinearLayout.LayoutParams(a.dp(38), a.dp(38))
                cl.rightMargin = a.dp(14)
                row.addView(circle, cl)
            }
            val tc = LinearLayout(a)
            tc.orientation = LinearLayout.VERTICAL
            val t = TextView(a)
            t.text = item.title
            t.textSize = if (dark) 17f else 16f
            t.typeface = if (dark) Typeface.DEFAULT else Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            t.setTextColor(
                if (dark) Color.parseColor("#F2F2F2")
                else if (item.selected) ORANGE else Color.parseColor("#1B1B1B")
            )
            t.maxLines = 2
            tc.addView(t)
            if (item.sub != null) {
                val s = TextView(a)
                s.text = item.sub
                s.textSize = 12.5f
                s.setTextColor(if (item.selected) ORANGE else Color.parseColor(if (dark) "#B0B0B0" else "#7A7A7A"))
                tc.addView(s)
            }
            row.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
            if (item.click != null) {
                row.setBackgroundResource(android.R.drawable.list_selector_background)
                row.setOnClickListener { _ -> win?.dismiss(); item.click.invoke() }
            }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
            if (item.divider) {
                val d = View(a)
                d.setBackgroundColor(Color.parseColor(if (dark) "#40FFFFFF" else "#E3E3E3"))
                val dl = LinearLayout.LayoutParams(-1, 1)
                if (dark) { dl.leftMargin = a.dp(16); dl.rightMargin = a.dp(16) }
                col.addView(d, dl)
            }
        }

        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)

        val dm = a.resources.displayMetrics
        val w = min(a.dp(widthDp), dm.widthPixels - a.dp(24))
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val rootH = anchor.rootView.height.takeIf { it > 0 } ?: dm.heightPixels
        val avail = (if (above) loc[1] - a.dp(56) else rootH - (loc[1] + anchor.height) - a.dp(24)).coerceAtLeast(a.dp(160))
        sv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val h = min(sv.measuredHeight, avail)

        val pw = PopupWindow(sv, w, h, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = a.dp(14).toFloat()
        win = pw
        if (above) {
            pw.showAtLocation(anchor.rootView, Gravity.BOTTOM or Gravity.END, a.dp(12),
                (rootH - loc[1]) + a.dp(6))
        } else {
            pw.showAtLocation(anchor.rootView, Gravity.TOP or Gravity.END, a.dp(8), loc[1] + anchor.height)
        }
        return pw
    }
}

// ------------------------------------------------------------------ printing / PDF

/** Opens Android's print dialog (which also has "Save as PDF") for one bitmap. */
class PicPrintAdapter(private val bmp: Bitmap, private val jobName: String) : PrintDocumentAdapter() {
    private var attrs: PrintAttributes? = null

    override fun onLayout(
        old: PrintAttributes?, new: PrintAttributes, cancel: CancellationSignal?,
        cb: LayoutResultCallback, extras: Bundle?
    ) {
        attrs = new
        if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
        cb.onLayoutFinished(
            PrintDocumentInfo.Builder("$jobName.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_PHOTO).setPageCount(1).build(), true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?,
        cb: WriteResultCallback
    ) {
        val ms = attrs?.mediaSize
        var wPt = ((ms?.widthMils ?: 8270) * 72) / 1000
        var hPt = ((ms?.heightMils ?: 11690) * 72) / 1000
        // landscape photo -> landscape page
        if (bmp.width > bmp.height && hPt > wPt) { val t = wPt; wPt = hPt; hPt = t }
        val doc = PdfDocument()
        try {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(wPt, hPt, 1).create())
            val margin = 28f
            val s = min((wPt - 2 * margin) / bmp.width, (hPt - 2 * margin) / bmp.height)
            val dw = bmp.width * s
            val dh = bmp.height * s
            page.canvas.drawBitmap(bmp, null,
                RectF((wPt - dw) / 2f, (hPt - dh) / 2f, (wPt + dw) / 2f, (hPt + dh) / 2f),
                Paint(Paint.FILTER_BITMAP_FLAG))
            doc.finishPage(page)
            FileOutputStream(dest.fileDescriptor).use { doc.writeTo(it) }
            cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Throwable) {
            cb.onWriteFailed(e.message)
        } finally {
            doc.close()
        }
    }
}

// ------------------------------------------------------------------ photo file helpers

object PicIO {
    /** "/storage/emulated/0/DCIM/Camera" -> "DCIM/Camera"; anything outside DCIM/Pictures -> "Pictures/<name>". */
    fun relPath(folder: String): String {
        val m = Regex(".*?/(DCIM|Pictures)(/.*)?$").find(folder)
        return if (m != null) m.groupValues[1] + m.groupValues[2] else "Pictures/" + folderName(folder)
    }

    /** Copy the original file bytes (no re-compression) into [folder]. Returns true on success. */
    @Suppress("DEPRECATION")
    fun copy(c: Context, pic: Pic, folder: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, pic.name)
                cv.put(MediaStore.Images.Media.MIME_TYPE, c.contentResolver.getType(pic.uri) ?: "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, relPath(folder))
                cv.put(MediaStore.Images.Media.IS_PENDING, 1)
                val u = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
                val ok = c.contentResolver.openInputStream(pic.uri)?.use { inp ->
                    c.contentResolver.openOutputStream(u)?.use { out -> inp.copyTo(out); true }
                } ?: false
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                c.contentResolver.update(u, cv, null, null)
                if (!ok) c.contentResolver.delete(u, null, null)
                ok
            } else {
                var dir = File(folder)
                if (!dir.exists() && !dir.mkdirs()) {
                    dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), folderName(folder))
                    dir.mkdirs()
                }
                var f = File(dir, pic.name)
                var n = 1
                while (f.exists()) {
                    f = File(dir, pic.name.substringBeforeLast('.') + "_" + n + "." + pic.name.substringAfterLast('.', "jpg"))
                    n++
                }
                val ok = c.contentResolver.openInputStream(pic.uri)?.use { inp ->
                    FileOutputStream(f).use { out -> inp.copyTo(out); true }
                } ?: false
                c.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)))
                ok
            }
        } catch (e: Throwable) { false }
    }

    /** Save a bitmap as a new JPEG into Pictures/VideoPlayer. */
    @Suppress("DEPRECATION")
    fun saveCopy(c: Context, bmp: Bitmap, name: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VideoPlayer")
                cv.put(MediaStore.Images.Media.IS_PENDING, 1)
                val u = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
                val ok = c.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                c.contentResolver.update(u, cv, null, null)
                ok
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VideoPlayer")
                dir.mkdirs()
                val f = File(dir, name)
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                c.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)))
                true
            }
        } catch (e: Throwable) { false }
    }

    /** Try to overwrite the original JPEG (works for files this app owns); false when not allowed. */
    fun overwrite(c: Context, uri: Uri, bmp: Bitmap): Boolean {
        return try {
            c.contentResolver.openOutputStream(uri, "wt")?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
        } catch (e: Throwable) { false }
    }
}

/** Dim top/bottom bar background helper. */
fun barBg(top: Boolean): GradientDrawable = GradientDrawable(
    if (top) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.BOTTOM_TOP,
    intArrayOf(Color.parseColor("#F0000000"), Color.parseColor("#B3000000"))
)

fun fmtSize(b: Long): String {
    if (b <= 0) return "-"
    val mb = b / 1048576.0
    return if (mb >= 1) String.format(java.util.Locale.US, "%.2f MB", mb)
    else String.format(java.util.Locale.US, "%.0f KB", b / 1024.0)
}

/**
 * Runs actions that need the user's permission on files this app does not own
 * (trash / delete / modify). Android 11+: system confirmation dialog. Android 10: RecoverableSecurityException.
 * Call [onResult] from onActivityResult.
 */
class Access(private val a: Activity, private val code: Int) {
    private var onGranted: (() -> Unit)? = null

    /** kind: 0 = move to trash, 1 = delete, 2 = modify (e.g. rename). [op] does the work, [ui] updates the screen. */
    fun run(kind: Int, uri: Uri, op: () -> Unit, ui: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val list = listOf(uri)
                val pi = when (kind) {
                    0 -> MediaStore.createTrashRequest(a.contentResolver, list, true)
                    1 -> MediaStore.createDeleteRequest(a.contentResolver, list)
                    else -> MediaStore.createWriteRequest(a.contentResolver, list)
                }
                onGranted = if (kind == 2) ({ guarded(op, ui) }) else ui
                a.startIntentSenderForResult(pi.intentSender, code, null, 0, 0, 0)
            } catch (e: Throwable) { fail() }
            return
        }
        try {
            op()
            ui()
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                onGranted = { guarded(op, ui) }
                try {
                    a.startIntentSenderForResult(e.userAction.actionIntent.intentSender, code, null, 0, 0, 0)
                } catch (t: Throwable) { fail() }
            } else fail()
        } catch (e: Throwable) { fail() }
    }

    private fun guarded(op: () -> Unit, ui: () -> Unit) {
        try { op(); ui() } catch (e: Throwable) { fail() }
    }

    fun onResult(req: Int, res: Int): Boolean {
        if (req != code) return false
        val g = onGranted
        onGranted = null
        if (res == Activity.RESULT_OK) g?.invoke()
        return true
    }

    private fun fail() { Toast.makeText(a, "Permission denied or action failed", Toast.LENGTH_SHORT).show() }
}
