package com.example.videoplayer

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Build
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

/** Real full screen (status bar + navigation bar hidden, notch area used when cutout = true). */
@Suppress("DEPRECATION")
fun Activity.immersive(cutout: Boolean = false) {
    if (cutout && Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
}

// ---------------------------------------------------------------- Equalizer

object Eq {
    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var vz: Virtualizer? = null
    private var session = 0

    private fun sp(c: Context) = c.getSharedPreferences("eq", 0)

    fun attach(c: Context, sessionId: Int) {
        if (sessionId <= 0) return
        if (sessionId == session && eq != null) return
        release()
        session = sessionId
        try { eq = Equalizer(0, sessionId) } catch (e: Throwable) { eq = null }
        try { bb = BassBoost(0, sessionId) } catch (e: Throwable) { bb = null }
        try { vz = Virtualizer(0, sessionId) } catch (e: Throwable) { vz = null }
        apply(c)
    }

    private fun release() {
        try { eq?.release() } catch (e: Throwable) {}
        try { bb?.release() } catch (e: Throwable) {}
        try { vz?.release() } catch (e: Throwable) {}
        eq = null; bb = null; vz = null
    }

    fun available() = eq != null
    fun enabled(c: Context) = sp(c).getBoolean("on", false)
    fun bands(): Int = try { eq?.numberOfBands?.toInt() ?: 0 } catch (e: Throwable) { 0 }
    fun range(): IntArray = try {
        val r = eq!!.bandLevelRange
        intArrayOf(r[0].toInt(), r[1].toInt())
    } catch (e: Throwable) { intArrayOf(-1500, 1500) }

    fun freqLabel(b: Int): String {
        val hz = try { (eq?.getCenterFreq(b.toShort()) ?: 0) / 1000 } catch (e: Throwable) { 0 }
        return if (hz >= 1000) String.format(java.util.Locale.US, "%.1f kHz", hz / 1000f) else "$hz Hz"
    }

    fun level(c: Context, b: Int) = sp(c).getInt("b$b", 0)
    fun bass(c: Context) = sp(c).getInt("bass", 0)
    fun virt(c: Context) = sp(c).getInt("virt", 0)

    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("on", v).apply(); apply(c) }
    fun setLevel(c: Context, b: Int, v: Int) { sp(c).edit().putInt("b$b", v).apply(); apply(c) }
    fun setBass(c: Context, v: Int) { sp(c).edit().putInt("bass", v).apply(); apply(c) }
    fun setVirt(c: Context, v: Int) { sp(c).edit().putInt("virt", v).apply(); apply(c) }

    fun presets(): List<String> = try {
        val e = eq!!
        (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
    } catch (e: Throwable) { emptyList() }

    fun usePreset(c: Context, i: Int) {
        try {
            val e = eq ?: return
            e.usePreset(i.toShort())
            val ed = sp(c).edit()
            for (b in 0 until e.numberOfBands.toInt()) ed.putInt("b$b", e.getBandLevel(b.toShort()).toInt())
            ed.putBoolean("on", true)
            ed.apply()
        } catch (t: Throwable) {}
        apply(c)
    }

    fun reset(c: Context) {
        val ed = sp(c).edit()
        for (b in 0 until bands()) ed.putInt("b$b", 0)
        ed.putInt("bass", 0).putInt("virt", 0).apply()
        apply(c)
    }

    fun apply(c: Context) {
        val on = enabled(c)
        try {
            eq?.let { e ->
                val r = range()
                for (b in 0 until e.numberOfBands.toInt()) e.setBandLevel(b.toShort(), level(c, b).coerceIn(r[0], r[1]).toShort())
                e.enabled = on
            }
        } catch (t: Throwable) {}
        try { bb?.let { it.setStrength(bass(c).toShort()); it.enabled = on && bass(c) > 0 } } catch (t: Throwable) {}
        try { vz?.let { it.setStrength(virt(c).toShort()); it.enabled = on && virt(c) > 0 } } catch (t: Throwable) {}
    }
}

fun eqDialog(a: Activity, session: Int = Music.player?.audioSessionId ?: 0) {
    Eq.attach(a, session)
    if (!Eq.available()) {
        Toast.makeText(a, "Equalizer: pehle koi song play karein (ya device support nahi karta)", Toast.LENGTH_LONG).show()
        return
    }
    val sv = ScrollView(a)
    val col = LinearLayout(a)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12))
    sv.addView(col)

    fun label(t: String): TextView {
        val tv = TextView(a)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.setPadding(0, a.dp(10), 0, 0)
        return tv
    }
    fun db(v: Int) = (if (v > 0) "+" else "") + String.format(java.util.Locale.US, "%.1f", v / 100f) + " dB"

    val sw = Switch(a)
    sw.text = "Equalizer ON / OFF"
    sw.setTextColor(Color.WHITE)
    sw.textSize = 18f
    sw.isChecked = Eq.enabled(a)
    sw.setOnCheckedChangeListener { _, on -> Eq.setEnabled(a, on) }
    col.addView(sw)

    val range = Eq.range()
    val n = Eq.bands()
    val bars = ArrayList<SeekBar>()
    val labels = ArrayList<TextView>()

    val presetBtn = label("Preset:  Custom  \u25BE")
    presetBtn.textSize = 16f
    presetBtn.setTextColor(Ui.ACCENT)
    presetBtn.setPadding(0, a.dp(16), 0, a.dp(6))
    presetBtn.setOnClickListener {
        val names = Eq.presets()
        if (names.isEmpty()) return@setOnClickListener
        AlertDialog.Builder(a).setTitle("Preset").setItems(names.toTypedArray()) { _, w ->
            Eq.usePreset(a, w)
            sw.isChecked = true
            presetBtn.text = "Preset:  " + names[w] + "  \u25BE"
            for (i in 0 until n) {
                bars[i].progress = Eq.level(a, i) - range[0]
                labels[i].text = Eq.freqLabel(i) + "    " + db(Eq.level(a, i))
            }
        }.show()
    }
    col.addView(presetBtn)

    for (i in 0 until n) {
        val l = label(Eq.freqLabel(i) + "    " + db(Eq.level(a, i)))
        val sb = SeekBar(a)
        sb.max = range[1] - range[0]
        sb.progress = Eq.level(a, i) - range[0]
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                val lv = v + range[0]
                if (!sw.isChecked) sw.isChecked = true
                Eq.setLevel(a, i, lv)
                l.text = Eq.freqLabel(i) + "    " + db(lv)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        bars.add(sb); labels.add(l)
        col.addView(l); col.addView(sb)
    }

    fun extra(title: String, get: () -> Int, set: (Int) -> Unit) {
        val l = label(title + "    " + get() / 10 + "%")
        val sb = SeekBar(a)
        sb.max = 1000
        sb.progress = get()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (!sw.isChecked) sw.isChecked = true
                set(v)
                l.text = title + "    " + v / 10 + "%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(l); col.addView(sb)
    }
    extra("Bass boost", { Eq.bass(a) }, { Eq.setBass(a, it) })
    extra("Surround (virtualizer)", { Eq.virt(a) }, { Eq.setVirt(a, it) })

    AlertDialog.Builder(a).setTitle("Equalizer").setView(sv)
        .setPositiveButton("Close", null)
        .setNeutralButton("Reset") { _, _ -> Eq.reset(a) }
        .show()
}

// ---------------------------------------------------------------- Photo zoom

/** ImageView with smooth pinch zoom (around the fingers), pan, double-tap zoom and swipe callbacks. */
class ZoomImageView(c: Context) : ImageView(c) {
    var onTap: (() -> Unit)? = null
    var onSwipe: ((Int) -> Unit)? = null
    var onZoomChanged: (() -> Unit)? = null

    private val m = Matrix()
    private val vals = FloatArray(9)
    private var base = 1f
    private var bw = 0
    private var bh = 0
    private val maxZoom = 8f
    private var anim: ValueAnimator? = null

    val zoomed: Boolean get() = base > 0f && curScale() / base > 1.02f

    init { scaleType = ImageView.ScaleType.MATRIX }

    private fun curScale(): Float { m.getValues(vals); return vals[Matrix.MSCALE_X] }

    override fun setImageBitmap(bm: Bitmap?) {
        super.setImageBitmap(bm)
        bw = bm?.width ?: 0
        bh = bm?.height ?: 0
        fit()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    fun fit() {
        if (bw == 0 || bh == 0 || width == 0 || height == 0) return
        anim?.cancel()
        base = min(width.toFloat() / bw, height.toFloat() / bh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - bw * base) / 2f, (height - bh * base) / 2f)
        imageMatrix = m
        onZoomChanged?.invoke()
    }

    private fun fix() {
        val r = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left
        else if (r.left > 0f) dx = -r.left
        else if (r.right < width) dx = width - r.right
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top
        else if (r.top > 0f) dy = -r.top
        else if (r.bottom < height) dy = height - r.bottom
        m.postTranslate(dx, dy)
        imageMatrix = m
    }

    private fun animateTo(target: Float, fx: Float, fy: Float) {
        anim?.cancel()
        val start = curScale()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 220
        a.addUpdateListener {
            val t = it.animatedValue as Float
            val s = start + (target - start) * t
            val f = s / curScale()
            m.postScale(f, f, fx, fy)
            fix()
            onZoomChanged?.invoke()
        }
        anim = a
        a.start()
    }

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val cur = curScale()
            if (cur <= 0f || base <= 0f) return true
            val target = (cur * d.scaleFactor).coerceIn(base, base * maxZoom)
            val f = target / cur
            m.postScale(f, f, d.focusX, d.focusY)
            fix()
            onZoomChanged?.invoke()
            return true
        }
    })

    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            animateTo(if (zoomed) base else base * 2.5f, e.x, e.y)
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (zoomed) { m.postTranslate(-dx, -dy); fix(); return true }
            return false
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (!zoomed && abs(vx) > abs(vy) && abs(vx) > 900f) { onSwipe?.invoke(if (vx < 0) 1 else -1); return true }
            return false
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (!sd.isInProgress) gd.onTouchEvent(e)
        return true
    }
}
