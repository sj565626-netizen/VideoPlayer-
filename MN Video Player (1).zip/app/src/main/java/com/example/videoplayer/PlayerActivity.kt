package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private var uris: List<String> = emptyList()
    private var land = false
    private var userRotated = false
    private var locked = false
    private var modeIdx = 0
    private var vw = 16
    private var vh = 9
    private var dragPos = -1L
    private var seeking = false
    private var inPip = false

    private lateinit var pv: PlayerView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var lockBtn: ImageView
    private lateinit var shotBtn: ImageView
    private lateinit var titleTv: TextView
    private lateinit var playBtn: ImageView
    private lateinit var speedBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var badge: TextView

    private val h = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { setControls(false) }
    private val tick = object : Runnable {
        override fun run() { upd(); h.postDelayed(this, 500) }
    }

    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val modeNames = arrayOf("Fit", "Fill (stretch)", "Zoom (crop)")
    private val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    // ---------------------------------------------------------------- helpers

    private fun circle(v: View) {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.parseColor("#66000000"))
        v.background = g
    }

    private fun icon(res: Int, sizeDp: Int, onClick: () -> Unit): ImageView {
        val iv = iconBtn(this, res, sizeDp)
        iv.setOnClickListener { onClick(); if (!locked) kick() }
        return iv
    }

    private fun nameOf(u: String): String = try {
        contentResolver.query(Uri.parse(u), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
            ?: Uri.parse(u).lastPathSegment ?: "Video"
    } catch (e: Throwable) { "Video" }

    private fun setLand(v: Boolean) {
        land = v
        requestedOrientation = if (v) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                               else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    private fun setControls(show: Boolean) {
        h.removeCallbacks(hideRun)
        val v = if (show && !inPip) View.VISIBLE else View.GONE
        if (locked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            shotBtn.visibility = View.GONE
            lockBtn.visibility = v
        } else {
            topBar.visibility = v
            bottomBar.visibility = v
            shotBtn.visibility = v
            lockBtn.visibility = v
        }
        if (v == View.VISIBLE) { upd(); h.postDelayed(hideRun, 3500) }
    }

    private fun controlsShown() = lockBtn.visibility == View.VISIBLE

    private fun kick() { if (controlsShown()) { h.removeCallbacks(hideRun); h.postDelayed(hideRun, 3500) } }

    private fun showBadge(t: String) {
        badge.text = t
        badge.visibility = View.VISIBLE
        badge.removeCallbacks(badgeHide)
        badge.postDelayed(badgeHide, 700)
    }
    private val badgeHide = Runnable { badge.visibility = View.GONE }

    private fun seekBy(ms: Long) {
        val p = player ?: return
        val d = if (p.duration > 0) p.duration else Long.MAX_VALUE
        p.seekTo((p.currentPosition + ms).coerceIn(0L, d))
        showBadge(if (ms > 0) "\u25B6\u25B6  +${ms / 1000}s" else "\u25C0\u25C0  ${ms / 1000}s")
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    private fun upd() {
        val p = player ?: return
        playBtn.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        if (seeking || !controlsShown()) return
        val d = if (p.duration > 0) p.duration else 0L
        seek.max = d.toInt()
        seek.progress = p.currentPosition.toInt()
        tCur.text = fmt(p.currentPosition)
        tTot.text = fmt(d)
    }

    private fun cycleAspect() {
        modeIdx = (modeIdx + 1) % modes.size
        pv.resizeMode = modes[modeIdx]
        showBadge(modeNames[modeIdx])
    }

    private fun cycleSpeed() {
        val p = player ?: return
        val i = speeds.indexOfFirst { it == p.playbackParameters.speed }
        val n = speeds[(i + 1) % speeds.size]
        p.setPlaybackSpeed(n)
        speedBtn.text = n.toString().uppercase(Locale.US) + "X"
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(vw.coerceAtLeast(1), vh.coerceAtLeast(1))).build())
            } catch (e: Throwable) {
                Toast.makeText(this, "Pop-up play is not supported", Toast.LENGTH_SHORT).show()
            }
        } else Toast.makeText(this, "Pop-up play needs Android 8+", Toast.LENGTH_SHORT).show()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        setControls(!isInPictureInPictureMode)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true && !locked) enterPip()
    }

    private fun menu() {
        val p = player ?: return
        AlertDialog.Builder(this).setItems(arrayOf("Playback speed", "Aspect ratio", "Equalizer", "Video info", "Share")) { _, w ->
            when (w) {
                0 -> AlertDialog.Builder(this).setTitle("Playback speed")
                    .setItems(speeds.map { it.toString() + "x" }.toTypedArray()) { _, i ->
                        p.setPlaybackSpeed(speeds[i]); speedBtn.text = speeds[i].toString() + "X"
                    }.show()
                1 -> AlertDialog.Builder(this).setTitle("Aspect ratio")
                    .setItems(modeNames) { _, i -> modeIdx = i; pv.resizeMode = modes[i] }.show()
                2 -> eqDialog(this, p.audioSessionId)
                3 -> {
                    val s = "Name: ${titleTv.text}\nSize: $vw x $vh\nDuration: ${fmt(p.duration.coerceAtLeast(0L))}"
                    AlertDialog.Builder(this).setTitle("Video info").setMessage(s).setPositiveButton("OK", null).show()
                }
                else -> p.currentMediaItem?.localConfiguration?.uri?.let {
                    val i = Intent(Intent.ACTION_SEND).setType("video/*")
                        .putExtra(Intent.EXTRA_STREAM, it)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Share"))
                }
            }
        }.show()
    }

    // ---------------------------------------------------------------- screenshot

    private fun screenshot() {
        val sv = pv.videoSurfaceView as? SurfaceView
        if (sv == null || sv.width == 0 || sv.height == 0 || Build.VERSION.SDK_INT < 24) {
            Toast.makeText(this, "Screenshot not available", Toast.LENGTH_SHORT).show(); return
        }
        val bmp = Bitmap.createBitmap(sv.width, sv.height, Bitmap.Config.ARGB_8888)
        PixelCopy.request(sv, bmp, { r ->
            if (r == PixelCopy.SUCCESS) {
                Thread {
                    val ok = try { saveJpeg(bmp) } catch (e: Throwable) { false }
                    runOnUiThread {
                        Toast.makeText(this, if (ok) "Screenshot saved: Pictures/VideoPlayer" else "Screenshot failed", Toast.LENGTH_SHORT).show()
                    }
                }.start()
            } else Toast.makeText(this, "Screenshot failed", Toast.LENGTH_SHORT).show()
        }, h)
    }

    @Suppress("DEPRECATION")
    private fun saveJpeg(bmp: Bitmap): Boolean {
        val name = "SHOT_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, name)
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VideoPlayer")
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            return contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VideoPlayer")
        dir.mkdirs()
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(f)))
        return true
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val list = intent.getStringArrayListExtra("u") ?: arrayListOf()
        val idx = intent.getIntExtra("i", 0)
        if (list.isEmpty()) { finish(); return }
        uris = list
        val prefs = getSharedPreferences("pos", 0)
        immersive(true)

        pv = PlayerView(this)
        pv.useController = false
        pv.setBackgroundColor(Color.BLACK)
        pv.resizeMode = modes[0]
        val p = ExoPlayer.Builder(this).build()
        player = p
        pv.player = p
        p.setMediaItems(list.map { MediaItem.fromUri(it) }, idx, prefs.getLong(list[idx], 0L))
        p.prepare()
        p.playWhenReady = true

        val root = GestureFrame(this) { !locked }
        root.setBackgroundColor(Color.BLACK)
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // touch layer: tap = show/hide controls, double tap = seek / play, drag = seek
        val touch = View(this)
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                setControls(!controlsShown()); return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = touch.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10000)
                    e.x > w * 2f / 3f -> seekBy(10000)
                    else -> togglePlay()
                }
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val pl = player ?: return false
                if (locked || abs(dx) <= abs(dy) || pl.duration <= 0) return false
                if (dragPos < 0) dragPos = pl.currentPosition
                dragPos = (dragPos - dx * 60f).toLong().coerceIn(0L, pl.duration)
                showBadge(fmt(dragPos) + " / " + fmt(pl.duration))
                return true
            }
        })
        touch.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            if ((e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) && dragPos >= 0) {
                if (e.actionMasked == MotionEvent.ACTION_UP) player?.seekTo(dragPos)
                dragPos = -1L
            }
            true
        }
        root.addView(touch, FrameLayout.LayoutParams(-1, -1))

        // top bar
        topBar = LinearLayout(this)
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(dp(20), dp(14), dp(20), dp(20))
        topBar.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#CC000000"), 0))
        titleTv = TextView(this)
        titleTv.text = nameOf(list[idx])
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 16f
        titleTv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        titleTv.setSingleLine(true)
        titleTv.ellipsize = android.text.TextUtils.TruncateAt.END
        titleTv.setPadding(dp(4), 0, dp(8), 0)
        topBar.addView(icon(R.drawable.ic_back, 44) { finish() })
        topBar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(icon(R.drawable.ic_pip, 44) { enterPip() })
        topBar.addView(icon(R.drawable.ic_more, 44) { menu() })
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // lock (left) and screenshot (right)
        lockBtn = icon(R.drawable.ic_unlock, 48) {
            locked = !locked
            lockBtn.setImageResource(if (locked) R.drawable.ic_lock else R.drawable.ic_unlock)
            if (locked) Toast.makeText(this, "Screen locked", Toast.LENGTH_SHORT).show()
            setControls(true)
        }
        circle(lockBtn)
        val ll = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        ll.leftMargin = dp(28)
        root.addView(lockBtn, ll)
        shotBtn = icon(R.drawable.ic_crop, 48) { screenshot() }
        circle(shotBtn)
        val sl = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL)
        sl.rightMargin = dp(28)
        root.addView(shotBtn, sl)

        // bottom bar
        bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.VERTICAL
        bottomBar.setPadding(dp(24), dp(24), dp(24), dp(16))
        bottomBar.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#CC000000"), 0))
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        tCur = TextView(this); tTot = TextView(this)
        for (t in listOf(tCur, tTot)) { t.setTextColor(Color.WHITE); t.textSize = 12f; t.typeface = android.graphics.Typeface.DEFAULT_BOLD }
        tCur.text = "00:00"; tTot.text = "00:00"
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(Color.WHITE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#66FFFFFF"))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) tCur.text = fmt(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { seeking = true; h.removeCallbacks(hideRun) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
                player?.seekTo((s?.progress ?: 0).toLong())
                kick()
            }
        })
        srow.addView(tCur)
        srow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        srow.addView(tTot)
        bottomBar.addView(srow, LinearLayout.LayoutParams(-1, -2))

        val brow = LinearLayout(this)
        brow.gravity = Gravity.CENTER_VERTICAL
        playBtn = icon(R.drawable.ic_pause, 52) { togglePlay() }
        speedBtn = TextView(this)
        speedBtn.text = "1.0X"
        speedBtn.setTextColor(Color.WHITE)
        speedBtn.textSize = 14f
        speedBtn.typeface = android.graphics.Typeface.DEFAULT_BOLD
        speedBtn.gravity = Gravity.CENTER
        speedBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
        speedBtn.setOnClickListener { cycleSpeed(); kick() }
        brow.addView(playBtn)
        brow.addView(icon(R.drawable.ic_next, 48) { player?.seekToNextMediaItem() })
        brow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        brow.addView(speedBtn)
        brow.addView(icon(R.drawable.ic_rotate, 48) { userRotated = true; setLand(!land) })
        brow.addView(icon(R.drawable.ic_aspect, 48) { cycleAspect() })
        bottomBar.addView(brow, LinearLayout.LayoutParams(-1, -2))
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // centre badge (+10s, seek position, aspect ratio ...)
        badge = TextView(this)
        badge.setTextColor(Color.WHITE)
        badge.textSize = 22f
        badge.gravity = Gravity.CENTER
        badge.setPadding(dp(22), dp(14), dp(22), dp(14))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#AA000000"))
        bg.cornerRadius = dp(16).toFloat()
        badge.background = bg
        badge.visibility = View.GONE
        root.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.width <= 0 || size.height <= 0) return
                val rot = size.unappliedRotationDegrees
                val w = if (rot == 90 || rot == 270) size.height else size.width
                val hh = if (rot == 90 || rot == 270) size.width else size.height
                vw = w; vh = hh
                if (!userRotated) setLand(w > hh)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { upd() }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                val u = item?.localConfiguration?.uri?.toString() ?: return
                titleTv.text = nameOf(u)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) setControls(true)
            }
        })

        setContentView(root)
        setLand(false)
        setControls(true)
    }

    override fun onStart() {
        super.onStart()
        h.post(tick)
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) immersive(true)
    }

    override fun onBackPressed() {
        if (locked) { Toast.makeText(this, "Screen is locked - tap the lock to unlock", Toast.LENGTH_SHORT).show(); return }
        super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        h.removeCallbacks(tick)
        player?.let { p ->
            p.currentMediaItem?.localConfiguration?.uri?.toString()?.let {
                getSharedPreferences("pos", 0).edit().putLong(it, p.currentPosition).apply()
            }
            p.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
