package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintManager
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhotoViewerActivity : Activity() {
    private var idx = 0
    private var token = 0
    private lateinit var iv: ZoomImageView
    private lateinit var overlay: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var dateTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var favIcon: ImageView
    private lateinit var noteTv: TextView
    private lateinit var saveChip: TextView
    private var list: MutableList<Pic> = ArrayList()
    private var curBmp: Bitmap? = null
    private var barsOn = true
    private var slideshow = false
    private val h = Handler(Looper.getMainLooper())
    private val access = Access(this, 51)
    private var pendingPerm: (() -> Unit)? = null
    private val slideRun = object : Runnable {
        override fun run() {
            if (!slideshow) return
            if (list.size > 1) { idx = (idx + 1) % list.size; show() }
            h.postDelayed(this, 3000)
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun pill(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(20), dp(10), dp(20), dp(10))
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#CC1C1C1E"))
        g.cornerRadius = dp(22).toFloat()
        tv.background = g
        return tv
    }

    private fun action(label: String, icon: Int, onClick: (View) -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(0, dp(6), 0, dp(4))
        c.addView(tintedIcon(icon, 24))
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(4), 0, 0)
        c.addView(t)
        c.setOnClickListener { onClick(c) }
        c.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        return c
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        list = ArrayList(Shared.pics)
        idx = intent.getIntExtra("i", 0)
        if (list.isEmpty() || idx !in list.indices) { finish(); return }

        iv = ZoomImageView(this)
        val root = GestureFrame(this) { !iv.zoomed }
        root.setBackgroundColor(Color.BLACK)
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))

        overlay = FrameLayout(this)

        // ---------------------------------------------------------- top bar: back | date + time | info
        topBar = LinearLayout(this)
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.background = barBg(true)
        val back = tintedIcon(R.drawable.ic_back, 48, Color.WHITE, 12)
        back.setOnClickListener { finish() }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        dateTv = TextView(this)
        dateTv.textSize = 20f
        dateTv.setTextColor(Color.WHITE)
        dateTv.setTypeface(null, android.graphics.Typeface.BOLD)
        dateTv.maxLines = 1
        timeTv = TextView(this)
        timeTv.textSize = 14f
        timeTv.setTextColor(Color.parseColor("#D0FFFFFF"))
        titles.addView(dateTv)
        titles.addView(timeTv)
        val info = tintedIcon(R.drawable.ic_info, 48, Color.WHITE, 11)
        info.setOnClickListener { showInfo() }
        topBar.addView(back)
        topBar.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(info)
        overlay.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---------------------------------------------------------- bottom: [chips] [note] [Share | Favorite | Edit | Delete | More]
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.gravity = Gravity.CENTER_HORIZONTAL

        saveChip = pill("Save rotation")
        saveChip.setTypeface(null, android.graphics.Typeface.BOLD)
        saveChip.setTextColor(Ui.ACCENT)
        saveChip.visibility = View.GONE
        saveChip.setOnClickListener { saveRotation() }
        val sl = LinearLayout.LayoutParams(-2, -2)
        sl.bottomMargin = dp(10)
        bottom.addView(saveChip, sl)

        noteTv = pill("")
        noteTv.maxLines = 3
        noteTv.visibility = View.GONE
        noteTv.setOnClickListener { addNote() }
        val nl = LinearLayout.LayoutParams(-2, -2)
        nl.bottomMargin = dp(10)
        nl.leftMargin = dp(24)
        nl.rightMargin = dp(24)
        bottom.addView(noteTv, nl)

        bottomBar = LinearLayout(this)
        bottomBar.background = barBg(false)
        bottomBar.setPadding(dp(4), dp(6), dp(4), dp(6))
        val share = action("Share", R.drawable.ic_share) { shareCur() }
        val fav = action("Favorite", R.drawable.ic_fav_off) { toggleFav() }
        favIcon = fav.getChildAt(0) as ImageView
        val edit = action("Edit", R.drawable.ic_edit) { openEditor(0) }
        val del = action("Delete", R.drawable.ic_delete) { confirmDelete() }
        val more = action("More", R.drawable.ic_more) { v -> moreMenu(v) }
        for (v in listOf(share, fav, edit, del, more)) bottomBar.addView(v)
        bottom.addView(bottomBar, LinearLayout.LayoutParams(-1, -2))
        overlay.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        iv.onTap = { if (slideshow) stopSlideshow() else setBars(!barsOn) }
        iv.onSwipe = { go(it) }
        setContentView(root)
        edgeToEdge(overlay) { l, t, r, bt ->
            topBar.setPadding(dp(4) + l, t + dp(6), dp(8) + r, dp(6))
            bottomBar.setPadding(dp(4) + l, dp(6), dp(4) + r, bt + dp(6))
            bottom.setPadding(0, 0, 0, 0)
        }
        show()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f && !barsOn) systemBars(false)
    }

    override fun onStop() {
        super.onStop()
        if (slideshow) stopSlideshow()
    }

    private fun setBars(on: Boolean) {
        barsOn = on
        overlay.visibility = if (on) View.VISIBLE else View.GONE
        systemBars(on)
    }

    private fun go(d: Int) {
        val n = idx + d
        if (n in list.indices) { idx = n; show() }
    }

    private fun show() {
        val pic = list[idx]
        val dt = Date(pic.dateSec * 1000)
        dateTv.text = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(dt)
        timeTv.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(dt)
        refreshFav()
        refreshNote()
        saveChip.visibility = View.GONE
        val my = ++token
        iv.setImageBitmap(null)
        curBmp = null
        Thread {
            val bmp = decode(pic.uri)
            runOnUiThread { if (my == token && bmp != null) { curBmp = bmp; iv.setImageBitmap(bmp) } }
        }.start()
    }

    private fun refreshFav() {
        val on = Prefs.isPicFav(this, list[idx].id)
        favIcon.setImageResource(if (on) R.drawable.ic_fav_on else R.drawable.ic_fav_off)
        favIcon.setColorFilter(if (on) Color.parseColor("#FF5A6E") else Color.WHITE)
    }

    private fun refreshNote() {
        val n = Prefs.picNote(this, list[idx].id)
        noteTv.text = n
        noteTv.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun removeCurrent(pic: Pic) {
        val i = list.indexOfFirst { it.id == pic.id }
        if (i < 0) return
        list.removeAt(i)
        if (list.isEmpty()) { finish(); return }
        if (idx >= list.size) idx = list.size - 1 else if (i < idx) idx--
        show()
    }

    // ------------------------------------------------------------------ bottom bar actions

    private fun shareCur() {
        val i = Intent(Intent.ACTION_SEND).setType("image/*")
            .putExtra(Intent.EXTRA_STREAM, list[idx].uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share"))
    }

    private fun toggleFav() {
        val on = Prefs.togglePicFav(this, list[idx].id)
        refreshFav()
        toast(if (on) "Added to favourites" else "Removed from favourites")
    }

    private fun openEditor(tab: Int) {
        startActivity(Intent(this, PhotoEditActivity::class.java)
            .putExtra("u", list[idx].uri.toString()).putExtra("tab", tab))
    }

    private fun confirmDelete() {
        val pic = list[idx]
        val trash = Build.VERSION.SDK_INT >= 30
        AlertDialog.Builder(this)
            .setTitle(if (trash) "Move to trash?" else "Delete photo?")
            .setMessage(pic.name)
            .setPositiveButton("Delete") { _, _ ->
                needWrite {
                    access.run(0, pic.uri,
                        op = { if (contentResolver.delete(pic.uri, null, null) < 1) throw IllegalStateException() },
                        ui = { Shared.dirty = true; toast("Deleted"); removeCurrent(pic) })
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ "More" menu (same options as the reference)

    private fun moreMenu(anchor: View) {
        val pic = list[idx]
        val hidden = Prefs.isPicHidden(this, pic.id)
        val items = listOf(
            PM("Move", click = { chooseFolder(true) }),
            PM("Copy", click = { chooseFolder(false) }),
            PM("Add notes", click = { addNote() }),
            PM(if (hidden) "Unhide" else "Hide", click = { toggleHide() }),
            PM("More edits", click = { moreEdits() }),
            PM("Slideshow", click = { startSlideshow() }),
            PM("Print or export to PDF", click = { printPdf() }),
            PM("Rename", click = { rename() }),
            PM("Set as", click = { setAs() }),
            PM("Rotate", divider = false, click = { rotate() })
        )
        PopMenu.show(this, anchor, items, dark = true, above = true, widthDp = 240)
    }

    // ---- move / copy
    private fun chooseFolder(move: Boolean) {
        val pic = list[idx]
        val folders = Shared.folders.filter { !move || it != pic.folder }
        val names = ArrayList<String>()
        for (f in folders) names.add(f.removePrefix("/storage/emulated/0/"))
        names.add("+  New album")
        AlertDialog.Builder(this).setTitle(if (move) "Move to" else "Copy to")
            .setItems(names.toTypedArray()) { _, w ->
                if (w == folders.size) newAlbum(move) else transfer(move, folders[w])
            }.show()
    }

    private fun newAlbum(move: Boolean) {
        val et = EditText(this)
        et.hint = "Album name"
        et.setSingleLine(true)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("New album").setView(box)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim().replace("/", "")
                if (n.isNotEmpty()) {
                    @Suppress("DEPRECATION")
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), n)
                    transfer(move, dir.path)
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun transfer(move: Boolean, folder: String) {
        val pic = list[idx]
        needWrite {
            toast(if (move) "Moving..." else "Copying...")
            Thread {
                val ok = PicIO.copy(this, pic, folder)
                runOnUiThread {
                    if (!ok) { toast("Could not copy the photo"); return@runOnUiThread }
                    Shared.dirty = true
                    val name = folderName(folder)
                    if (!move) { toast("Copied to $name"); return@runOnUiThread }
                    access.run(1, pic.uri,
                        op = { if (contentResolver.delete(pic.uri, null, null) < 1) throw IllegalStateException() },
                        ui = { toast("Moved to $name"); removeCurrent(pic) })
                }
            }.start()
        }
    }

    // ---- notes
    private fun addNote() {
        val pic = list[idx]
        val et = EditText(this)
        et.hint = "Write a note"
        et.setText(Prefs.picNote(this, pic.id))
        et.minLines = 3
        et.gravity = Gravity.TOP or Gravity.START
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("Add notes").setView(box)
            .setPositiveButton("Save") { _, _ -> Prefs.setPicNote(this, pic.id, et.text.toString()); refreshNote() }
            .setNeutralButton("Remove") { _, _ -> Prefs.setPicNote(this, pic.id, ""); refreshNote() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---- hide / unhide
    private fun toggleHide() {
        val pic = list[idx]
        val hide = !Prefs.isPicHidden(this, pic.id)
        Prefs.setPicHidden(this, pic.id, hide)
        Shared.dirty = true
        toast(if (hide) "Photo hidden (see Albums > Hidden)" else "Photo is visible again")
        removeCurrent(pic)
    }

    // ---- more edits
    private fun moreEdits() {
        AlertDialog.Builder(this).setTitle("More edits")
            .setItems(arrayOf("Filters", "Adjust", "Rotate & flip", "Crop")) { _, w -> openEditor(w) }.show()
    }

    // ---- slideshow
    private fun startSlideshow() {
        if (list.size < 2) { toast("Need at least 2 photos for a slideshow"); return }
        slideshow = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setBars(false)
        toast("Slideshow - tap to stop")
        h.removeCallbacks(slideRun)
        h.postDelayed(slideRun, 3000)
    }

    private fun stopSlideshow() {
        slideshow = false
        h.removeCallbacks(slideRun)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setBars(true)
    }

    // ---- print / PDF
    private fun printPdf() {
        val bmp = curBmp
        if (bmp == null) { toast("Photo is still loading"); return }
        val name = list[idx].name.substringBeforeLast('.')
        try {
            (getSystemService(PRINT_SERVICE) as PrintManager).print(name, PicPrintAdapter(bmp, name), null)
        } catch (e: Throwable) { toast("Printing is not available on this device") }
    }

    // ---- rename
    private fun rename() {
        val pic = list[idx]
        val dot = pic.name.lastIndexOf('.')
        val base = if (dot > 0) pic.name.substring(0, dot) else pic.name
        val ext = if (dot > 0) pic.name.substring(dot) else ""
        val et = EditText(this)
        et.setText(base)
        et.setSingleLine(true)
        et.selectAll()
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("Rename").setView(box)
            .setPositiveButton("OK") { _, _ ->
                val nb = et.text.toString().trim().replace("/", "")
                val newName = nb + ext
                if (nb.isEmpty() || newName == pic.name) return@setPositiveButton
                needWrite {
                    access.run(2, pic.uri,
                        op = {
                            val cv = ContentValues()
                            cv.put(MediaStore.Images.Media.DISPLAY_NAME, newName)
                            if (contentResolver.update(pic.uri, cv, null, null) < 1) throw IllegalStateException()
                        },
                        ui = {
                            val i = list.indexOfFirst { it.id == pic.id }
                            if (i >= 0) list[i] = list[i].copy(name = newName)
                            Shared.dirty = true
                            toast("Renamed")
                        })
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---- set as
    private fun setAs() {
        val pic = list[idx]
        AlertDialog.Builder(this).setTitle("Set as")
            .setItems(arrayOf("Wallpaper", "Lock screen", "Wallpaper and lock screen", "Other app...")) { _, w ->
                if (w == 3) {
                    val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(pic.uri, "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try { startActivity(Intent.createChooser(i, "Set as")) } catch (e: Throwable) { toast("No app found") }
                } else {
                    toast("Setting...")
                    Thread {
                        val ok = try {
                            val bmp = decode(pic.uri) ?: throw IllegalStateException()
                            val flag = when (w) {
                                0 -> WallpaperManager.FLAG_SYSTEM
                                1 -> WallpaperManager.FLAG_LOCK
                                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                            }
                            WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flag)
                            true
                        } catch (e: Throwable) { false }
                        runOnUiThread { toast(if (ok) "Wallpaper updated" else "Could not set the wallpaper") }
                    }.start()
                }
            }.show()
    }

    // ---- rotate (+ save)
    private fun rotate() {
        val b = curBmp
        if (b == null) { toast("Photo is still loading"); return }
        val my = token
        Thread {
            val nb = try {
                val m = Matrix()
                m.postRotate(90f)
                Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            } catch (e: Throwable) { null }
            runOnUiThread {
                if (nb != null && my == token) {
                    curBmp = nb
                    iv.setImageBitmap(nb)
                    saveChip.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun saveRotation() {
        val bmp = curBmp ?: return
        val pic = list[idx]
        needWrite {
            Thread {
                val jpg = pic.name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") }
                var ok = jpg && PicIO.overwrite(this, pic.uri, bmp)
                var msg = "Rotation saved"
                if (!ok) {
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    ok = PicIO.saveCopy(this, bmp, "ROT_$stamp.jpg")
                    msg = "Saved as a copy in Pictures/VideoPlayer"
                }
                runOnUiThread {
                    if (ok) { saveChip.visibility = View.GONE; Shared.dirty = true; toast(msg) }
                    else toast("Could not save")
                }
            }.start()
        }
    }

    // ---- info
    private fun showInfo() {
        val pic = list[idx]
        var size = "-"
        var res = "-"
        var mime = "-"
        try {
            contentResolver.query(pic.uri, arrayOf(MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.MIME_TYPE), null, null, null)?.use {
                if (it.moveToFirst()) {
                    size = fmtSize(it.getLong(0))
                    res = it.getInt(1).toString() + " x " + it.getInt(2)
                    mime = it.getString(3) ?: "-"
                }
            }
        } catch (e: Throwable) {}
        val dt = SimpleDateFormat("MMM d, yyyy  h:mm a", Locale.getDefault()).format(Date(pic.dateSec * 1000))
        var msg = "Name:  ${pic.name}\nDate:  $dt\nResolution:  $res\nSize:  $size\nFormat:  $mime\nFolder:  ${pic.folder}"
        val n = Prefs.picNote(this, pic.id)
        if (n.isNotEmpty()) msg += "\nNote:  $n"
        AlertDialog.Builder(this).setTitle("Details").setMessage(msg).setPositiveButton("Close", null).show()
    }

    // ------------------------------------------------------------------ permissions / results

    private fun needWrite(op: () -> Unit) {
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingPerm = op
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 78)
            return
        }
        op()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        val op = pendingPerm
        pendingPerm = null
        if (code == 78 && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) op?.invoke()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        access.onResult(req, res)
    }

    // ------------------------------------------------------------------ decode

    private fun decode(uri: Uri): Bitmap? {
        return try {
            val cr = contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 3072 || o.outHeight / ss > 3072) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val ori = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
            } catch (e: Throwable) { 1 }
            val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            bmp
        } catch (e: Throwable) { null }
    }
}
