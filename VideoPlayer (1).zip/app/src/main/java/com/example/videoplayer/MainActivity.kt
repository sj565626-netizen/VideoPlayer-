package com.example.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class Vid(
    val id: Long, val uri: String, val name: String,
    val dur: Long, val size: Long, val date: Long, val folder: String
)

fun fmtDur(ms: Long): String {
    val s = if (ms < 0) 0L else ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

class MainActivity : Activity() {
    private val all = ArrayList<Vid>()
    private var shown: List<Vid> = emptyList()
    private var folders: List<Pair<String, Int>> = emptyList()
    private var query = ""
    private var sort = 0
    private var tab = 0
    private var openFolder: String? = null
    private var inPrivate = false
    private var emptyText = ""
    private val priv = HashSet<String>()

    private lateinit var heading: TextView
    private lateinit var searchBox: EditText
    private lateinit var tabs: LinearLayout
    private lateinit var tabV: TextView
    private lateinit var tabF: TextView
    private lateinit var grid: GridView
    private lateinit var flist: ListView
    private lateinit var msg: TextView

    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                       else Manifest.permission.READ_EXTERNAL_STORAGE
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<Long, Bitmap>(150)
    private val fmt = SimpleDateFormat("yyyy/MM/dd", Locale.US)
    private val blue = 0xFF2F6BFF.toInt()
    private val gray = 0xFF9A9A9A.toInt()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun prefs() = getSharedPreferences("priv", 0)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        priv.addAll(prefs().getStringSet("ids", emptySet()) ?: emptySet())

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(8), dp(4))
        heading = TextView(this)
        heading.text = "Video Player"
        heading.textSize = 20f
        heading.setTextColor(Color.WHITE)
        heading.typeface = Typeface.DEFAULT_BOLD
        heading.maxLines = 1
        heading.ellipsize = TextUtils.TruncateAt.END
        searchBox = EditText(this)
        searchBox.hint = "Search videos"
        searchBox.setHintTextColor(gray)
        searchBox.setTextColor(Color.WHITE)
        searchBox.setSingleLine(true)
        searchBox.setBackgroundColor(Color.TRANSPARENT)
        searchBox.visibility = View.GONE
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString(); refresh() }
        })
        head.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(searchBox, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(icon(android.R.drawable.ic_menu_sort_by_size) { sortDialog() })
        head.addView(icon(android.R.drawable.ic_menu_search) { toggleSearch() })
        head.addView(icon(android.R.drawable.ic_menu_more) { moreDialog() })

        tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER
        tabs.setPadding(0, dp(8), 0, dp(8))
        tabV = tabText("Videos") { tab = 0; openFolder = null; refresh() }
        tabF = tabText("Folders") { tab = 1; openFolder = null; refresh() }
        tabs.addView(tabV)
        tabs.addView(tabF)

        val content = FrameLayout(this)
        grid = GridView(this)
        grid.numColumns = 3
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.horizontalSpacing = dp(8)
        grid.verticalSpacing = dp(12)
        grid.setPadding(dp(12), dp(8), dp(12), dp(8))
        grid.clipToPadding = false
        grid.setSelector(android.R.color.transparent)
        grid.adapter = GridAdapter()
        grid.setOnItemClickListener { _, _, pos, _ ->
            startActivity(
                Intent(this, PlayerActivity::class.java)
                    .putStringArrayListExtra("u", ArrayList(shown.map { it.uri }))
                    .putStringArrayListExtra("n", ArrayList(shown.map { it.name }))
                    .putExtra("i", pos)
            )
        }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            val v = shown[pos]
            val label = if (inPrivate) "Remove from private" else "Make private"
            AlertDialog.Builder(this).setTitle(v.name)
                .setItems(arrayOf(label)) { _, _ ->
                    if (inPrivate) {
                        priv.remove(v.id.toString()); savePriv(); refresh()
                        toast("Removed from private")
                    } else {
                        withPin {
                            priv.add(v.id.toString()); savePriv(); refresh()
                            toast("Moved to private")
                        }
                    }
                }.show()
            true
        }
        flist = ListView(this)
        flist.divider = null
        flist.setSelector(android.R.color.transparent)
        flist.adapter = FolderAdapter()
        flist.setOnItemClickListener { _, _, pos, _ -> openFolder = folders[pos].first; refresh() }
        msg = TextView(this)
        msg.setTextColor(gray)
        msg.gravity = Gravity.CENTER
        msg.setPadding(dp(24), dp(24), dp(24), dp(24))
        msg.visibility = View.GONE
        msg.setOnClickListener { check() }
        content.addView(grid, FrameLayout.LayoutParams(-1, -1))
        content.addView(flist, FrameLayout.LayoutParams(-1, -1))
        content.addView(msg, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        root.addView(head)
        root.addView(tabs)
        root.addView(content, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        check()
    }

    private fun icon(res: Int, click: () -> Unit): ImageButton {
        val i = ImageButton(this)
        i.setImageResource(res)
        i.setColorFilter(Color.WHITE)
        i.setBackgroundColor(Color.TRANSPARENT)
        i.setOnClickListener { click() }
        i.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        return i
    }

    private fun tabText(t: String, click: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 17f
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(22), dp(8), dp(22), dp(8))
        v.setOnClickListener { click() }
        return v
    }

    private fun savePriv() { prefs().edit().putStringSet("ids", HashSet(priv)).apply() }

    private fun pinDialog(setting: Boolean, ok: () -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = if (setting) "Set a PIN (4+ digits)" else "Enter PIN"
        AlertDialog.Builder(this)
            .setTitle(if (setting) "Create private PIN" else "Private PIN")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString()
                if (setting) {
                    if (t.length >= 4) { prefs().edit().putString("pin", t).apply(); ok() }
                    else toast("PIN must be at least 4 digits")
                } else if (t == prefs().getString("pin", null)) ok()
                else toast("Wrong PIN")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun withPin(ok: () -> Unit) = pinDialog(prefs().getString("pin", null) == null, ok)

    private fun moreDialog() {
        val item = if (inPrivate) "Exit private videos" else "Private videos"
        AlertDialog.Builder(this).setItems(arrayOf(item)) { _, _ ->
            if (inPrivate) { inPrivate = false; refresh() }
            else withPin { inPrivate = true; tab = 0; openFolder = null; refresh() }
        }.show()
    }

    private fun sortDialog() {
        AlertDialog.Builder(this).setTitle("Sort by")
            .setItems(arrayOf("Newest first", "Oldest first", "Name (A-Z)", "Size (largest)")) { _, w ->
                sort = w; refresh()
            }.show()
    }

    private fun toggleSearch() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (searchBox.visibility == View.VISIBLE) {
            searchBox.setText("")
            searchBox.visibility = View.GONE
            heading.visibility = View.VISIBLE
            imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        } else {
            heading.visibility = View.GONE
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            imm.showSoftInput(searchBox, 0)
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            inPrivate -> { inPrivate = false; refresh() }
            openFolder != null -> { openFolder = null; refresh() }
            searchBox.visibility == View.VISIBLE -> toggleSearch()
            else -> super.onBackPressed()
        }
    }

    private fun check() {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(perm), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) load()
        else {
            emptyText = "Permission is needed to show your videos. Tap here to allow, or enable it in Settings > Apps > Video Player > Permissions."
            refresh()
        }
    }

    private fun load() {
        all.clear()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val cols = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        contentResolver.query(base, cols, null, null, null)?.use {
            while (it.moveToNext()) {
                all.add(
                    Vid(
                        it.getLong(0), ContentUris.withAppendedId(base, it.getLong(0)).toString(),
                        it.getString(1) ?: "Video", it.getLong(2), it.getLong(3), it.getLong(4),
                        it.getString(5) ?: "Other"
                    )
                )
            }
        }
        emptyText = "No videos found on this phone."
        refresh()
    }

    private fun refresh() {
        tabV.setTextColor(if (tab == 0) blue else gray)
        tabF.setTextColor(if (tab == 1) blue else gray)
        tabs.visibility = if (inPrivate) View.GONE else View.VISIBLE
        val q = query.trim()
        val base = all.filter { priv.contains(it.id.toString()) == inPrivate }
        if (!inPrivate && tab == 1 && openFolder == null) {
            val m = LinkedHashMap<String, Int>()
            for (v in base) m[v.folder] = (m[v.folder] ?: 0) + 1
            folders = m.entries.map { Pair(it.key, it.value) }
                .filter { q.isEmpty() || it.first.contains(q, true) }
                .sortedBy { it.first.lowercase() }
            grid.visibility = View.GONE
            flist.visibility = View.VISIBLE
            (flist.adapter as BaseAdapter).notifyDataSetChanged()
            msg.text = if (base.isEmpty()) emptyText else "No folders found."
            msg.visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
            heading.text = "Video Player"
        } else {
            var l = base.filter { openFolder == null || it.folder == openFolder }
            if (q.isNotEmpty()) l = l.filter { it.name.contains(q, true) }
            l = when (sort) {
                0 -> l.sortedByDescending { it.date }
                1 -> l.sortedBy { it.date }
                2 -> l.sortedBy { it.name.lowercase() }
                else -> l.sortedByDescending { it.size }
            }
            shown = l
            flist.visibility = View.GONE
            grid.visibility = View.VISIBLE
            (grid.adapter as BaseAdapter).notifyDataSetChanged()
            msg.text = if (inPrivate && base.isEmpty()) "No private videos yet. Long-press a video to make it private."
                       else if (base.isEmpty()) emptyText else "No videos found."
            msg.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
            heading.text = if (inPrivate) "Private" else (openFolder ?: "Video Player")
        }
    }

    private fun cellW(): Int = (resources.displayMetrics.widthPixels - dp(24) - dp(16)) / 3

    private fun sizeText(b: Long): String {
        val mb = b / 1048576.0
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024)
        else if (mb >= 100) String.format(Locale.US, "%.0f MB", mb)
        else String.format(Locale.US, "%.2f MB", mb)
    }

    @Suppress("DEPRECATION")
    private fun loadThumb(h: Holder, v: Vid) {
        h.id = v.id
        val c = cache.get(v.id)
        if (c != null) { h.img.setImageBitmap(c); return }
        h.img.setImageDrawable(null)
        pool.execute {
            val bm: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29)
                    contentResolver.loadThumbnail(Uri.parse(v.uri), Size(320, 320), null)
                else
                    MediaStore.Video.Thumbnails.getThumbnail(
                        contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
            } catch (e: Exception) { null }
            if (bm != null) {
                cache.put(v.id, bm)
                runOnUiThread { if (h.id == v.id) h.img.setImageBitmap(bm) }
            }
        }
    }

    private inner class Holder {
        val root = LinearLayout(this@MainActivity)
        val img = ImageView(this@MainActivity)
        val dur = TextView(this@MainActivity)
        val name = TextView(this@MainActivity)
        val meta = TextView(this@MainActivity)
        var id = -1L

        init {
            val w = cellW()
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(0xFF222222.toInt())
            img.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) {
                    o.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            img.clipToOutline = true
            dur.setTextColor(Color.WHITE)
            dur.textSize = 12f
            dur.typeface = Typeface.DEFAULT_BOLD
            dur.setShadowLayer(4f, 0f, 0f, Color.BLACK)
            dur.setPadding(dp(8), 0, 0, dp(6))
            val fr = FrameLayout(this@MainActivity)
            fr.addView(img, FrameLayout.LayoutParams(w, w))
            fr.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
            name.textSize = 13f
            name.setTextColor(Color.WHITE)
            name.typeface = Typeface.DEFAULT_BOLD
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            name.setPadding(0, dp(6), 0, 0)
            meta.textSize = 12f
            meta.setTextColor(gray)
            meta.maxLines = 2
            root.orientation = LinearLayout.VERTICAL
            root.addView(fr, LinearLayout.LayoutParams(w, w))
            root.addView(name, LinearLayout.LayoutParams(w, -2))
            root.addView(meta, LinearLayout.LayoutParams(w, -2))
            root.tag = this
        }
    }

    private inner class GridAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int): Any = shown[p]
        override fun getItemId(p: Int) = shown[p].id
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val h = (cv?.tag as? Holder) ?: Holder()
            val v = shown[p]
            h.name.text = v.name
            h.meta.text = fmt.format(Date(v.date * 1000)) + "\n" + sizeText(v.size)
            h.dur.text = fmtDur(v.dur)
            loadThumb(h, v)
            return h.root
        }
    }

    private inner class FolderAdapter : BaseAdapter() {
        override fun getCount() = folders.size
        override fun getItem(p: Int): Any = folders[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val l = LinearLayout(this@MainActivity)
            l.orientation = LinearLayout.VERTICAL
            l.setPadding(dp(20), dp(14), dp(20), dp(14))
            val n = TextView(this@MainActivity)
            n.text = folders[p].first
            n.textSize = 17f
            n.setTextColor(Color.WHITE)
            n.typeface = Typeface.DEFAULT_BOLD
            val c = TextView(this@MainActivity)
            c.text = "${folders[p].second} videos"
            c.textSize = 13f
            c.setTextColor(gray)
            l.addView(n)
            l.addView(c)
            return l
        }
    }
}
