package com.example.videoplayer

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private var land = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pv: PlayerView
    private lateinit var top: LinearLayout
    private lateinit var bottom: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var cur: TextView
    private lateinit var tot: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var speedBtn: TextView
    private lateinit var aspectBtn: TextView
    private val speeds = floatArrayOf(0.5f, 1f, 1.25f, 1.5f, 2f)
    private var si = 1
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val modeNames = arrayOf("FIT", "CROP", "STRETCH")
    private var ai = 0
    private var dragging = false
    private var showing = true
    private var names = ArrayList<String>()

    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 500) }
    }
    private val hide = Runnable { setControls(false) }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uris = intent.getStringArrayListExtra("u") ?: arrayListOf()
        names = intent.getStringArrayListExtra("n") ?: arrayListOf()
        val idx = intent.getIntExtra("i", 0)
        if (uris.isEmpty()) { finish(); return }
        val prefs = getSharedPreferences("pos", 0)

        pv = PlayerView(this)
        pv.useController = false
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        val p = ExoPlayer.Builder(this).build()
        player = p
        pv.player = p
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, idx, prefs.getLong(uris[idx], 0L))
        p.prepare()
        p.playWhenReady = true

        // top bar
        top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setBackgroundColor(0x66000000)
        top.setPadding(dp(8), dp(28), dp(8), dp(8))
        val back = TextView(this)
        back.text = "←"
        back.textSize = 28f
        back.setTextColor(Color.WHITE)
        back.setPadding(dp(12), 0, dp(12), 0)
        back.setOnClickListener { finish() }
        titleTv = TextView(this)
        titleTv.text = names.getOrNull(idx) ?: ""
        titleTv.textSize = 17f
        titleTv.setTextColor(Color.WHITE)
        titleTv.typeface = Typeface.DEFAULT_BOLD
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.MIDDLE
        aspectBtn = pill(modeNames[0]) {
            ai = (ai + 1) % modes.size
            pv.resizeMode = modes[ai]
            aspectBtn.text = modeNames[ai]
            kick()
        }
        top.addView(back)
        top.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(aspectBtn)

        // bottom bar
        bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(0x66000000)
        bottom.setPadding(dp(16), dp(8), dp(16), dp(24))
        cur = timeText("00:00")
        tot = timeText("00:00")
        seek = SeekBar(this)
        seek.max = 1000
        seek.progressTintList = ColorStateList.valueOf(Color.WHITE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                val d = player?.duration ?: 0L
                if (fromUser && d > 0) cur.text = fmtDur(d * v / 1000)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true; h.removeCallbacks(hide) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                val d = player?.duration ?: 0L
                if (d > 0) player?.seekTo(d * (s?.progress ?: 0) / 1000)
                dragging = false
                kick()
            }
        })
        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.gravity = Gravity.CENTER_VERTICAL
        timeRow.addView(cur)
        timeRow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(tot)

        playBtn = ibtn(android.R.drawable.ic_media_pause) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            kick()
        }
        val next = ibtn(android.R.drawable.ic_media_next) {
            player?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() }
            kick()
        }
        speedBtn = pill("1.0X") {
            si = (si + 1) % speeds.size
            player?.setPlaybackSpeed(speeds[si])
            speedBtn.text = "${speeds[si]}X"
            kick()
        }
        val rot = ibtn(android.R.drawable.ic_menu_rotate) {
            land = !land
            requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                   else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            kick()
        }
        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER_VERTICAL
        btnRow.addView(playBtn)
        btnRow.addView(next)
        btnRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnRow.addView(speedBtn)
        btnRow.addView(rot)
        bottom.addView(timeRow, LinearLayout.LayoutParams(-1, -2))
        bottom.addView(btnRow, LinearLayout.LayoutParams(-1, -2))

        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                playBtn.setColorFilter(Color.WHITE)
                kick()
            }
            override fun onMediaItemTransition(m: MediaItem?, reason: Int) {
                titleTv.text = names.getOrNull(p.currentMediaItemIndex) ?: ""
            }
        })

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        pv.setOnClickListener { setControls(!showing) }
        setContentView(root)
        h.post(tick)
        kick()
    }

    private fun ibtn(res: Int, click: () -> Unit): ImageButton {
        val i = ImageButton(this)
        i.setImageResource(res)
        i.setColorFilter(Color.WHITE)
        i.setBackgroundColor(Color.TRANSPARENT)
        i.setOnClickListener { click() }
        i.layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        return i
    }

    private fun pill(t: String, click: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.typeface = Typeface.DEFAULT_BOLD
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(12), dp(10), dp(12), dp(10))
        v.setOnClickListener { click() }
        return v
    }

    private fun timeText(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 12f
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(4), 0, dp(4), 0)
        return v
    }

    private fun update() {
        val p = player ?: return
        val d = p.duration
        if (d > 0 && !dragging) {
            seek.progress = (p.currentPosition * 1000 / d).toInt()
            cur.text = fmtDur(p.currentPosition)
        }
        if (d > 0) tot.text = fmtDur(d)
    }

    private fun setControls(show: Boolean) {
        showing = show
        val v = if (show) View.VISIBLE else View.GONE
        top.visibility = v
        bottom.visibility = v
        h.removeCallbacks(hide)
        if (show && player?.isPlaying == true) h.postDelayed(hide, 3500)
    }

    private fun kick() = setControls(true)

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onStop() {
        super.onStop()
        player?.let { p ->
            p.currentMediaItem?.localConfiguration?.uri?.toString()?.let {
                getSharedPreferences("pos", 0).edit().putLong(it, p.currentPosition).apply()
            }
            p.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
