Video Player (native Android, Kotlin + Media3)
Build with GitHub Actions: put this zip in a repo as VideoPlayer.zip with the build.yml workflow (see chat), run it, download APK from Artifacts.
Or open this folder in Android Studio and run Build > Build APK.
